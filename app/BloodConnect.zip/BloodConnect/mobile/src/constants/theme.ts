// ─────────────────────────────────────────────────────────────
// BloodConnect — Thème Premium Médical
// Blanc pur · Rouge profond · Glassmorphism · Ombres fortes
// ─────────────────────────────────────────────────────────────

export const COLORS = {
  // Rouges
  crimson:      '#9B1B30',   // rouge profond signature
  crimsonDark:  '#6B0F20',   // rouge très foncé
  crimsonLight: '#C0392B',   // rouge vif
  crimsonGlow:  'rgba(155, 27, 48, 0.18)',  // halo rouge
  crimsonFrost: 'rgba(155, 27, 48, 0.08)',  // teinté rouge léger

  // Blancs & neutres
  white:        '#FFFFFF',
  snowWhite:    '#FAFAFA',
  ghostWhite:   '#F7F8FC',
  silver:       '#F0F2F7',
  mist:         '#E8EAF0',
  fog:          '#D4D8E4',

  // Textes
  ink:          '#0F1117',   // quasi-noir
  slate:        '#2D3142',   // gris très foncé
  steel:        '#5A6075',   // gris moyen
  muted:        '#9299AF',   // gris clair

  // États
  success:      '#1A7F5A',
  successLight: 'rgba(26, 127, 90, 0.12)',
  warning:      '#D4700A',
  warningLight: 'rgba(212, 112, 10, 0.12)',
  danger:       '#9B1B30',
  dangerLight:  'rgba(155, 27, 48, 0.12)',

  // Glassmorphism
  glass:        'rgba(255, 255, 255, 0.72)',
  glassBorder:  'rgba(255, 255, 255, 0.45)',
  glassDark:    'rgba(15, 17, 23, 0.06)',
  glassDarkBorder: 'rgba(15, 17, 23, 0.08)',

  // Overlays
  overlay:      'rgba(15, 17, 23, 0.55)',
  overlayLight: 'rgba(15, 17, 23, 0.25)',
};

export const FONTS = {
  // Utilise les polices système premium
  display:  'System',
  body:     'System',
  mono:     'System',
};

export const SPACING = {
  xs:   4,
  sm:   8,
  md:   16,
  lg:   24,
  xl:   32,
  xxl:  48,
  xxxl: 64,
};

export const RADIUS = {
  xs:   6,
  sm:   12,
  md:   18,
  lg:   24,
  xl:   32,
  xxl:  40,
  full: 9999,
};

export const SHADOW = {
  // Ombres fortes signature du style
  soft: {
    shadowColor:   '#0F1117',
    shadowOffset:  { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius:  8,
    elevation:     3,
  },
  card: {
    shadowColor:   '#0F1117',
    shadowOffset:  { width: 0, height: 8 },
    shadowOpacity: 0.10,
    shadowRadius:  20,
    elevation:     8,
  },
  strong: {
    shadowColor:   '#0F1117',
    shadowOffset:  { width: 0, height: 16 },
    shadowOpacity: 0.16,
    shadowRadius:  32,
    elevation:     16,
  },
  crimson: {
    shadowColor:   '#9B1B30',
    shadowOffset:  { width: 0, height: 8 },
    shadowOpacity: 0.32,
    shadowRadius:  20,
    elevation:     10,
  },
};

export const GRADIENT = {
  crimson:    ['#9B1B30', '#6B0F20'],
  crimsonSoft:['#C0392B', '#9B1B30'],
  light:      ['#FFFFFF', '#F7F8FC'],
  card:       ['#FFFFFF', '#FAFAFA'],
};