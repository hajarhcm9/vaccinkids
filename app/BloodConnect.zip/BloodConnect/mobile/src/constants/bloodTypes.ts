import { BloodType } from '../types';

export const BLOOD_TYPES: BloodType[] = [
  'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-',
];

export const COMPATIBILITE: Record<BloodType, BloodType[]> = {
  'A+':  ['A+', 'A-', 'O+', 'O-'],
  'A-':  ['A-', 'O-'],
  'B+':  ['B+', 'B-', 'O+', 'O-'],
  'B-':  ['B-', 'O-'],
  'AB+': ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
  'AB-': ['A-', 'B-', 'AB-', 'O-'],
  'O+':  ['O+', 'O-'],
  'O-':  ['O-'],
};

export const BADGE_COLORS: Record<string, string> = {
  critique: '#9B1B30',
  urgent:   '#D4700A',
  normal:   '#1A7F5A',
};

export const BADGE_BG: Record<string, string> = {
  critique: 'rgba(155, 27, 48, 0.10)',
  urgent:   'rgba(212, 112, 10, 0.10)',
  normal:   'rgba(26, 127, 90, 0.10)',
};

export const BADGE_LABELS: Record<string, string> = {
  critique: 'CRITIQUE',
  urgent:   'URGENT',
  normal:   'NORMAL',
};