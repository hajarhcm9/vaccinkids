export type BloodType = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
export type UserRole = 'donneur' | 'hopital';
export type AnnonceType = 'besoin' | 'offre';
export type BadgeType = 'critique' | 'urgent' | 'normal';
export type UrgenceType = 'normale' | 'urgente';

export interface User {
  uid: string;
  nom: string;
  idNational: string;
  email: string;
  role: UserRole;
  groupeSanguin?: BloodType;
  hopitalNom?: string;
  fcmToken?: string;
  createdAt?: string;
}

export interface Annonce {
  id: string;
  type: AnnonceType;
  auteurId: string;
  auteurNom: string;
  role: UserRole;
  groupesRecherches?: BloodType[];
  groupePropose?: BloodType;
  urgence: UrgenceType;
  localisation: string;
  description?: string;
  dateExpiration: any;
  statut: 'active' | 'cloturee';
  priorityScore?: number;
  priorityBadge?: BadgeType;
  priorityRaison?: string;
  createdAt: any;
}

export type RootStackParamList = {
  Auth: undefined;
  Main: undefined;
};

export type MainTabParamList = {
  Home: undefined;
  Post: undefined;
  Profile: undefined;
  Notifications: undefined;
};

export type HomeStackParamList = {
  HomeList: undefined;
  Detail: { annonceId: string };
};