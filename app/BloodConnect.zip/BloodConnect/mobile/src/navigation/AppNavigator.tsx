import React from 'react';
import { ActivityIndicator, View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { AuthContext } from '../context/AuthContext';
import { useAuth }     from '../hooks/useAuth';
import { COLORS, RADIUS, SHADOW } from '../constants/theme';

// ── Imports avec vérification explicite ───────────────────────────────────
// On importe et on vérifie immédiatement — si undefined, on affiche un fallback
import { AuthScreen }      from '../screens/AuthScreen';
import { HomeScreen }      from '../screens/HomeScreen';
import { PostScreen }      from '../screens/PostScreen';
import { ProfileScreen }   from '../screens/ProfileScreen';
import { DetailScreen }    from '../screens/DetailScreen';
import { AssistantScreen } from '../screens/AssistantScreen';

// Réexport pour compatibilité screens existants
export { AuthContext };

// ── Écran de fallback si un composant est undefined ───────────────────────
const Fallback: React.FC<{ name: string }> = ({ name }) => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: COLORS.ghostWhite }}>
    <Text style={{ color: COLORS.crimson, fontWeight: '700', fontSize: 16 }}>
      Erreur : {name} est undefined
    </Text>
    <Text style={{ color: COLORS.muted, fontSize: 12, marginTop: 8 }}>
      Vérifiez l'export du composant
    </Text>
  </View>
);

// Wrapper sécurisé — retourne le composant ou un fallback lisible
const safe = (Component: any, name: string) =>
  Component ?? (() => <Fallback name={name} />);

// ── Navigators ────────────────────────────────────────────────────────────
const RootStack = createNativeStackNavigator();
const Tab       = createBottomTabNavigator();
const HomeStack = createNativeStackNavigator();

// ── Home Stack (liste + détail) ───────────────────────────────────────────
const HomeStackNavigator = () => (
  <HomeStack.Navigator>
    <HomeStack.Screen
      name="HomeList"
      component={safe(HomeScreen, 'HomeScreen')}
      options={{ headerShown: false }}
    />
    <HomeStack.Screen
      name="Detail"
      component={safe(DetailScreen, 'DetailScreen')}
      options={{
        title:               "Détail de l'annonce",
        headerStyle:         { backgroundColor: COLORS.crimsonDark },
        headerTintColor:     COLORS.white,
        headerTitleStyle:    { fontWeight: '700', fontSize: 16 },
        headerShadowVisible: false,
      }}
    />
  </HomeStack.Navigator>
);

// ── Icônes tab custom ─────────────────────────────────────────────────────
const HomeIcon = ({ color, focused }: { color: string; focused: boolean }) => (
  <View style={{ width: 26, height: 26, justifyContent: 'center', alignItems: 'center' }}>
    <View style={{
      position: 'absolute', top: 2,
      width: 0, height: 0,
      borderLeftWidth: 13, borderRightWidth: 13, borderBottomWidth: 10,
      borderLeftColor: 'transparent', borderRightColor: 'transparent',
      borderBottomColor: focused ? COLORS.crimson : color,
    }} />
    <View style={{
      position: 'absolute', bottom: 2, width: 16, height: 11,
      backgroundColor: focused ? COLORS.crimson : color, borderRadius: 2,
    }} />
    <View style={{
      position: 'absolute', bottom: 2, width: 6, height: 7,
      backgroundColor: focused ? COLORS.white : COLORS.ghostWhite, borderRadius: 1,
    }} />
  </View>
);

const PlusIcon = ({ focused }: { focused: boolean }) => (
  <View style={{
    width: 40, height: 40, borderRadius: RADIUS.sm,
    backgroundColor: focused ? COLORS.crimson : COLORS.ghostWhite,
    justifyContent: 'center', alignItems: 'center', marginTop: -6,
    borderWidth: focused ? 0 : 1.5, borderColor: COLORS.fog,
    ...SHADOW.soft,
  }}>
    <View style={{ position: 'absolute', width: focused ? 20 : 16, height: focused ? 5 : 4, backgroundColor: focused ? COLORS.white : COLORS.steel, borderRadius: 2 }} />
    <View style={{ position: 'absolute', width: focused ? 5 : 4, height: focused ? 20 : 16, backgroundColor: focused ? COLORS.white : COLORS.steel, borderRadius: 2 }} />
  </View>
);

const CrossIcon = ({ color, focused }: { color: string; focused: boolean }) => (
  <View style={{
    width: 26, height: 26, borderRadius: RADIUS.xs,
    backgroundColor: focused ? COLORS.crimson : 'transparent',
    borderWidth: focused ? 0 : 1.5, borderColor: color,
    justifyContent: 'center', alignItems: 'center',
  }}>
    <View style={{ position: 'absolute', width: focused ? 12 : 10, height: focused ? 4 : 3, backgroundColor: focused ? COLORS.white : color, borderRadius: 1 }} />
    <View style={{ position: 'absolute', width: focused ? 4 : 3, height: focused ? 12 : 10, backgroundColor: focused ? COLORS.white : color, borderRadius: 1 }} />
  </View>
);

const CircleIcon = ({ color, focused }: { color: string; focused: boolean }) => (
  <View style={{
    width: 26, height: 26, borderRadius: 13,
    backgroundColor: focused ? COLORS.crimson : 'transparent',
    borderWidth: focused ? 0 : 1.5, borderColor: color,
    justifyContent: 'center', alignItems: 'center',
  }}>
    <View style={{ width: focused ? 10 : 8, height: focused ? 10 : 8, borderRadius: 99, backgroundColor: focused ? COLORS.white : color }} />
  </View>
);

// ── Main Tabs ─────────────────────────────────────────────────────────────
const MainTabs = () => (
  <Tab.Navigator
    screenOptions={{
      tabBarActiveTintColor:   COLORS.crimson,
      tabBarInactiveTintColor: COLORS.muted,
      tabBarStyle: {
        borderTopColor:  COLORS.mist,
        borderTopWidth:  1,
        backgroundColor: COLORS.white,
        elevation:       16,
        shadowColor:     '#0F1117',
        shadowOffset:    { width: 0, height: -4 },
        shadowOpacity:   0.08,
        shadowRadius:    12,
        height:          62,
        paddingBottom:   8,
        paddingTop:      4,
      },
      tabBarLabelStyle: { fontSize: 10, fontWeight: '700', letterSpacing: 0.2, marginTop: 2 },
      headerShown: false,
    }}
  >
    <Tab.Screen
      name="Home"
      component={HomeStackNavigator}
      options={{ tabBarLabel: 'Accueil', tabBarIcon: ({ color, focused }) => <HomeIcon color={color} focused={focused} /> }}
    />
    <Tab.Screen
      name="Post"
      component={safe(PostScreen, 'PostScreen')}
      options={{ tabBarLabel: 'Publier', tabBarIcon: ({ focused }) => <PlusIcon focused={focused} /> }}
    />
    <Tab.Screen
      name="Assistant"
      component={safe(AssistantScreen, 'AssistantScreen')}
      options={{ tabBarLabel: 'Assistant', tabBarIcon: ({ color, focused }) => <CrossIcon color={color} focused={focused} /> }}
    />
    <Tab.Screen
      name="Profile"
      component={safe(ProfileScreen, 'ProfileScreen')}
      options={{ tabBarLabel: 'Profil', tabBarIcon: ({ color, focused }) => <CircleIcon color={color} focused={focused} /> }}
    />
  </Tab.Navigator>
);

// ── Root ──────────────────────────────────────────────────────────────────
export const AppNavigator: React.FC = () => {
  const { firebaseUser, userProfile, loading } = useAuth();

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: COLORS.ghostWhite }}>
        <ActivityIndicator size="large" color={COLORS.crimson} />
      </View>
    );
  }

  return (
    <AuthContext.Provider value={{ userProfile }}>
      <NavigationContainer>
        <RootStack.Navigator screenOptions={{ headerShown: false }}>
          {firebaseUser ? (
            <RootStack.Screen
              name="Main"
              component={MainTabs}
            />
          ) : (
            <RootStack.Screen
              name="Auth"
              component={safe(AuthScreen, 'AuthScreen')}
            />
          )}
        </RootStack.Navigator>
      </NavigationContainer>
    </AuthContext.Provider>
  );
};
