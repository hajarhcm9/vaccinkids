// ─────────────────────────────────────────────────────────────────────────────
// expo-notifications (push remote) a été retiré d'Expo Go depuis SDK 53.
// Ce fichier ne contient AUCUN import de expo-notifications.
//
// Pour activer les vraies notifications push :
//   1. Compilez un development build : npx expo run:android
//   2. Décommentez le code dans ce fichier
// ─────────────────────────────────────────────────────────────────────────────

export const registerForPushNotifications = async (
  _uid: string,
): Promise<string | null> => {
  console.log('[Notif] Expo Go SDK 53+ : push notifications nécessitent un dev build.');
  return null;
};

export const addNotificationListener = (
  _handler: (n: unknown) => void,
) => ({ remove: () => {} });

export const addResponseListener = (
  _handler: (r: unknown) => void,
) => ({ remove: () => {} });