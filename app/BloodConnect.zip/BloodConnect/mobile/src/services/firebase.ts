import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  initializeAuth,
  getAuth,
  getReactNativePersistence,
} from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';

const firebaseConfig = {
  apiKey:            process.env.EXPO_PUBLIC_FIREBASE_API_KEY             || '',
  authDomain:        process.env.EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN         || '',
  projectId:         process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID          || '',
  storageBucket:     process.env.EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET      || '',
  messagingSenderId: process.env.EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
  appId:             process.env.EXPO_PUBLIC_FIREBASE_APP_ID              || '',
};

// ── App init (safe against duplicate calls on hot reload) ──────────────────
const app = getApps().length === 0
  ? initializeApp(firebaseConfig)
  : getApp();

// ── Auth init (initializeAuth ne peut être appelé qu'une seule fois)
// Si l'app existe déjà (hot reload), on utilise getAuth() à la place ──────
let auth: ReturnType<typeof getAuth>;
try {
  auth = initializeAuth(app, {
    persistence: getReactNativePersistence(AsyncStorage),
  });
} catch (_e) {
  // L'auth a déjà été initialisée (hot reload Expo) — on récupère l'instance
  auth = getAuth(app);
}

// ── Firestore ──────────────────────────────────────────────────────────────
const db = getFirestore(app);

export { auth, db };
export default app;