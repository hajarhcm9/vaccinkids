import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  doc, setDoc, getDoc, updateDoc, serverTimestamp,
} from 'firebase/firestore';
import { auth, db } from './firebase';
import { User, BloodType, UserRole } from '../types';

export const register = async (
  email: string,
  password: string,
  nom: string,
  idNational: string,
  role: UserRole,
  groupeSanguin?: BloodType,
  hopitalNom?: string,
): Promise<User> => {
  const cred = await createUserWithEmailAndPassword(auth, email, password);
  const uid = cred.user.uid;

  const userData: User = {
    uid,
    nom,
    idNational,
    email,
    role,
    ...(role === 'donneur' && groupeSanguin ? { groupeSanguin } : {}),
    ...(role === 'hopital' && hopitalNom   ? { hopitalNom }   : {}),
  };

  await setDoc(doc(db, 'users', uid), {
    ...userData,
    createdAt: serverTimestamp(),
  });

  return userData;
};

export const login = async (
  email: string,
  password: string,
): Promise<FirebaseUser> => {
  const cred = await signInWithEmailAndPassword(auth, email, password);
  return cred.user;
};

export const logout = async (): Promise<void> => {
  await signOut(auth);
};

export const getProfile = async (uid: string): Promise<User | null> => {
  const snap = await getDoc(doc(db, 'users', uid));
  if (!snap.exists()) return null;
  return snap.data() as User;
};

export const updateFcmToken = async (
  uid: string,
  token: string,
): Promise<void> => {
  await updateDoc(doc(db, 'users', uid), { fcmToken: token });
};

export const subscribeToAuthChanges = (
  callback: (user: FirebaseUser | null) => void,
) => onAuthStateChanged(auth, callback);