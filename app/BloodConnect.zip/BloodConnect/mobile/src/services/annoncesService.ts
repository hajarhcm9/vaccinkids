import {
  collection, query, where, orderBy,
  onSnapshot, getDoc, doc,
} from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import axios from 'axios';
import { db } from './firebase';
import { Annonce, BloodType, AnnonceType, UrgenceType, UserRole } from '../types';

const BACKEND_URL = process.env.EXPO_PUBLIC_BACKEND_URL || 'http://192.168.1.8:3000';

const getAuthHeader = async (): Promise<{ Authorization: string }> => {
  const user = getAuth().currentUser;
  if (!user) throw new Error('Utilisateur non connecté');
  const token = await user.getIdToken();
  return { Authorization: `Bearer ${token}` };
};

export interface CreateAnnoncePayload {
  type:               AnnonceType;
  auteurId:           string;
  auteurNom:          string;
  role:               UserRole;
  urgence:            UrgenceType;
  localisation:       string;
  description?:       string;
  dateExpiration:     Date;
  groupesRecherches?: BloodType[];
  groupePropose?:     BloodType;
}

export const createAnnonce = async (payload: CreateAnnoncePayload): Promise<string> => {
  const headers = await getAuthHeader();
  const response = await axios.post(
    `${BACKEND_URL}/api/annonces`,
    {
      type:              payload.type,
      urgence:           payload.urgence,
      localisation:      payload.localisation,
      description:       payload.description,
      dateExpiration:    payload.dateExpiration.toISOString(),
      groupesRecherches: payload.groupesRecherches,
      groupePropose:     payload.groupePropose,
    },
    { headers, timeout: 10000 }
  );
  return response.data.data.id;
};

export const cloturerAnnonce = async (id: string): Promise<void> => {
  const headers = await getAuthHeader();
  await axios.patch(
    `${BACKEND_URL}/api/annonces/${id}/cloturer`,
    {},
    { headers, timeout: 10000 }
  );
};

export const getAnnonceById = async (id: string): Promise<Annonce | null> => {
  const snap = await getDoc(doc(db, 'annonces', id));
  if (!snap.exists()) return null;
  return { id: snap.id, ...snap.data() } as Annonce;
};

// ─────────────────────────────────────────────────────────────────────────────
// FIX : suppression du orderBy('createdAt') combiné avec where('statut')
// Firestore exige un index composite pour cette combinaison — on trie côté client
// ─────────────────────────────────────────────────────────────────────────────
export const subscribeToAnnonces = (callback: (annonces: Annonce[]) => void) => {
  const q = query(
    collection(db, 'annonces'),
    where('statut', '==', 'active'),
    // PAS de orderBy ici pour éviter l'index composite manquant
    // Le tri est fait côté client ci-dessous
  );

  return onSnapshot(q, snap => {
    const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as Annonce));

    // Tri côté client : priorityScore décroissant, puis createdAt décroissant
    data.sort((a, b) => {
      const scoreDiff = (b.priorityScore ?? 0) - (a.priorityScore ?? 0);
      if (scoreDiff !== 0) return scoreDiff;
      // Fallback sur createdAt
      const dateA = a.createdAt?.toDate?.() ?? new Date(0);
      const dateB = b.createdAt?.toDate?.() ?? new Date(0);
      return dateB.getTime() - dateA.getTime();
    });

    callback(data);
  });
};