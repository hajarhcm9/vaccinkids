import { useState, useEffect } from 'react';
import { subscribeToAnnonces } from '../services/annoncesService';
import { Annonce } from '../types';

export const useAnnonces = () => {
  const [annonces, setAnnonces] = useState<Annonce[]>([]);
  const [loading,  setLoading]  = useState(true);
  const [error,    setError]    = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    const unsub = subscribeToAnnonces(data => {
      setAnnonces(data);
      setLoading(false);
    });
    return () => {
      unsub();
    };
  }, []);

  const besoins = annonces.filter(a => a.type === 'besoin');
  const offres  = annonces.filter(a => a.type === 'offre');

  return { annonces, besoins, offres, loading, error };
};