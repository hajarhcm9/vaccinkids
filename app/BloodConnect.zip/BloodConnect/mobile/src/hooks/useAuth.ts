import { useState, useEffect } from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import { subscribeToAuthChanges, getProfile } from '../services/authService';
import { User } from '../types';

interface AuthState {
  firebaseUser: FirebaseUser | null;
  userProfile:  User | null;
  loading:      boolean;
}

export const useAuth = (): AuthState => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [userProfile,  setUserProfile]  = useState<User | null>(null);
  const [loading,      setLoading]      = useState(true);

  useEffect(() => {
    const unsub = subscribeToAuthChanges(async fbUser => {
      setFirebaseUser(fbUser);
      if (fbUser) {
        const profile = await getProfile(fbUser.uid);
        setUserProfile(profile);
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  return { firebaseUser, userProfile, loading };
};