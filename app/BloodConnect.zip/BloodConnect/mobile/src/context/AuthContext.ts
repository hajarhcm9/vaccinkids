// Fichier séparé pour éviter les require cycles
// AppNavigator et les screens importent depuis ici, pas l'un depuis l'autre

import { createContext } from 'react';
import { User } from '../types';

export interface AuthContextType {
  userProfile: User | null;
}

export const AuthContext = createContext<AuthContextType>({ userProfile: null });