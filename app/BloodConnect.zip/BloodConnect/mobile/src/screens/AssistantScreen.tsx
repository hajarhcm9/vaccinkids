import React, { useState, useRef, useContext } from 'react';
import {
  View, Text, StyleSheet, FlatList, TextInput,
  TouchableOpacity, ActivityIndicator, KeyboardAvoidingView,
  Platform, StatusBar,
} from 'react-native';
import { AuthContext } from '../context/AuthContext';
import { COLORS, SPACING, RADIUS, SHADOW } from '../constants/theme';

interface Message {
  id:        string;
  role:      'user' | 'assistant';
  content:   string;
  timestamp: Date;
}

interface GeminiMessage {
  role:  'user' | 'model';
  parts: { text: string }[];
}

const SUGGESTIONS = [
  'Qui peut donner du sang ?',
  'Comment se préparer avant un don ?',
  'Quels sont les groupes sanguins rares ?',
  'Combien de temps dure un don de sang ?',
  'Quelles sont les contre-indications ?',
  'Quelle est la fréquence maximale de don ?',
  'Que se passe-t-il après le don ?',
  'Mon groupe O- est-il universel ?',
];

const SYSTEM_INSTRUCTION = `Tu es un assistant médical expert et bienveillant spécialisé dans le don de sang, intégré à l'application BloodConnect au Maroc.

Ton rôle est d'aider les utilisateurs à comprendre :
- Les conditions et critères pour donner du sang
- La préparation avant un don (alimentation, hydratation, repos)
- Le déroulement d'un don de sang (étapes, durée, sensations)
- Les contre-indications temporaires et permanentes
- Les groupes sanguins et leur compatibilité
- La fréquence autorisée des dons selon le type
- Les bénéfices du don pour la santé du donneur
- L'importance du don de sang au Maroc
- Comment répondre à une annonce urgente sur BloodConnect

Règles :
- Réponds TOUJOURS en français
- Sois clair, rassurant et encourageant
- Langage accessible et non technique
- Si une question dépasse tes compétences, recommande un médecin
- Ne donne jamais de diagnostics médicaux personnels
- Reste dans le domaine du don de sang et de BloodConnect
- Réponses concises (max 200 mots) mais complètes`;

const Bubble: React.FC<{ message: Message }> = ({ message }) => {
  const isUser = message.role === 'user';
  const time   = message.timestamp.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

  return (
    <View style={[styles.bubbleRow, isUser && styles.bubbleRowUser]}>
      {!isUser && (
        <View style={[styles.aiAvatar, SHADOW.soft]}>
          <View style={styles.crossH} />
          <View style={styles.crossV} />
        </View>
      )}
      <View style={[styles.bubble, isUser ? styles.bubbleUser : styles.bubbleAI, isUser ? SHADOW.crimson : SHADOW.soft]}>
        <Text style={[styles.bubbleText, isUser && styles.bubbleTextUser]}>{message.content}</Text>
        <Text style={[styles.bubbleTime, isUser && styles.bubbleTimeUser]}>{time}</Text>
      </View>
    </View>
  );
};

export const AssistantScreen: React.FC = () => {
  const { userProfile }    = useContext(AuthContext);
  const firstName          = userProfile?.nom?.split(' ')[0] ?? '';
  const listRef            = useRef<FlatList>(null);

  const [messages, setMessages] = useState<Message[]>([{
    id:        'welcome',
    role:      'assistant',
    content:   `Bonjour${firstName ? ' ' + firstName : ''} ! Je suis votre assistant BloodConnect.\n\nJe suis ici pour répondre à toutes vos questions sur le don de sang : conditions requises, préparation, déroulement, compatibilité des groupes sanguins et bien plus.\n\nComment puis-je vous aider ?`,
    timestamp: new Date(),
  }]);
  const [input,           setInput]           = useState('');
  const [loading,         setLoading]         = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(true);

  const scrollToBottom = () =>
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 120);

  const sendMessage = async (text: string) => {
    const content = text.trim();
    if (!content || loading) return;

    setShowSuggestions(false);
    setInput('');

    const userMsg: Message = { id: `u_${Date.now()}`, role: 'user', content, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);
    scrollToBottom();

    try {
      const history: GeminiMessage[] = messages
        .filter(m => m.id !== 'welcome')
        .map(m => ({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: m.content }] }));

      const contents: GeminiMessage[] = [...history, { role: 'user', parts: [{ text: content }] }];

      const GEMINI_API_KEY = process.env.EXPO_PUBLIC_GEMINI_API_KEY ?? '';

      // Chaque modèle a sa propre version d'API correcte
      const MODELS: { model: string; apiVersion: string }[] = [
        { model: 'gemini-1.5-flash',      apiVersion: 'v1'     },
        { model: 'gemini-1.5-flash-8b',   apiVersion: 'v1'     },
        { model: 'gemini-1.5-pro',         apiVersion: 'v1'     },
        { model: 'gemini-2.0-flash-lite',  apiVersion: 'v1beta' },
        { model: 'gemini-2.0-flash',       apiVersion: 'v1beta' },
      ];

      const callGemini = async (model: string, apiVersion: string) => {
        const url = `https://generativelanguage.googleapis.com/${apiVersion}/models/${model}:generateContent?key=${GEMINI_API_KEY}`;
        const res = await fetch(url, {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            system_instruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
            contents,
            generationConfig: { maxOutputTokens: 512, temperature: 0.7 },
          }),
        });

        if (!res.ok) {
          const err = await res.json();
          // 429 = quota dépassé → essayer le modèle suivant
          // 404 = modèle non trouvé → essayer le modèle suivant
          if (res.status === 429 || res.status === 404) {
            throw new Error('TRY_NEXT');
          }
          throw new Error(err.error?.message ?? `Erreur ${res.status}`);
        }
        return res.json();
      };

      let data: any = null;
      let lastError = '';

      for (const { model, apiVersion } of MODELS) {
        try {
          data = await callGemini(model, apiVersion);
          console.log(`[Gemini] OK — ${model} (${apiVersion})`);
          break;
        } catch (e: any) {
          if (e.message === 'TRY_NEXT') {
            console.warn(`[Gemini] ${model} indisponible, essai suivant...`);
            lastError = `${model} indisponible`;
            continue;
          }
          throw e;
        }
      }

      if (!data) throw new Error(`Tous les modèles sont indisponibles. ${lastError}`);

      const aiText = data.candidates?.[0]?.content?.parts?.[0]?.text
        ?? 'Désolé, je n\'ai pas pu générer une réponse. Réessayez.';

      setMessages(prev => [...prev, { id: `a_${Date.now()}`, role: 'assistant', content: aiText, timestamp: new Date() }]);

    } catch (err: any) {
      console.error('[Gemini] Erreur:', err.message);
      const isQuota = err.message?.includes('quota') || err.message?.includes('Tous les modèles');
      setMessages(prev => [...prev, {
        id: `e_${Date.now()}`, role: 'assistant',
        content: isQuota
          ? 'Quota Gemini épuisé sur tous les modèles gratuits. Attendez quelques minutes et réessayez, ou activez la facturation sur aistudio.google.com.'
          : 'Difficultés techniques. Vérifiez votre connexion et votre clé API Gemini dans le fichier .env.',
        timestamp: new Date(),
      }]);
    } finally {
      setLoading(false);
      scrollToBottom();
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      <StatusBar barStyle="light-content" backgroundColor={COLORS.crimsonDark} />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.bgCircle} />
        <View style={styles.headerLeft}>
          <View style={[styles.headerAvatar, SHADOW.soft]}>
            <View style={styles.crossH} />
            <View style={styles.crossV} />
          </View>
          <View>
            <Text style={styles.headerTitle}>Assistant Médical</Text>
            <View style={styles.onlineRow}>
              <View style={styles.onlineDot} />
              <Text style={styles.onlineText}>Disponible 24h/24 · Gemini AI</Text>
            </View>
          </View>
        </View>
        <TouchableOpacity style={styles.resetBtn} onPress={() => { setMessages([{ id: 'welcome', role: 'assistant', content: 'Conversation réinitialisée. Comment puis-je vous aider ?', timestamp: new Date() }]); setShowSuggestions(true); }}>
          <Text style={styles.resetBtnText}>Effacer</Text>
        </TouchableOpacity>
      </View>

      {/* Messages */}
      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <Bubble message={item} />}
        contentContainerStyle={styles.messageList}
        showsVerticalScrollIndicator={false}
        onContentSizeChange={scrollToBottom}
        ListFooterComponent={
          <>
            {loading && (
              <View style={styles.bubbleRow}>
                <View style={[styles.aiAvatar, SHADOW.soft]}>
                  <View style={styles.crossH} />
                  <View style={styles.crossV} />
                </View>
                <View style={[styles.bubble, styles.bubbleAI, styles.loadingBubble, SHADOW.soft]}>
                  <ActivityIndicator size="small" color={COLORS.crimson} />
                  <Text style={styles.loadingText}>En cours de rédaction...</Text>
                </View>
              </View>
            )}
            {showSuggestions && !loading && (
              <View style={[styles.suggestionsCard, SHADOW.card]}>
                <View style={styles.suggestionsHeader}>
                  <View style={styles.suggestionsHeaderDot} />
                  <Text style={styles.suggestionsTitle}>Questions fréquentes</Text>
                </View>
                {SUGGESTIONS.map((q, i) => (
                  <TouchableOpacity
                    key={i}
                    style={[styles.suggestionItem, i === SUGGESTIONS.length - 1 && { borderBottomWidth: 0 }]}
                    onPress={() => sendMessage(q)}
                    activeOpacity={0.75}
                  >
                    <Text style={styles.suggestionText}>{q}</Text>
                    <Text style={styles.suggestionArrow}>›</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </>
        }
      />

      {/* Input */}
      <View style={[styles.inputBar, SHADOW.strong]}>
        <TextInput
          style={styles.input}
          value={input}
          onChangeText={setInput}
          placeholder="Posez votre question..."
          placeholderTextColor={COLORS.muted}
          multiline maxLength={500}
          returnKeyType="send"
          onSubmitEditing={() => sendMessage(input)}
        />
        <TouchableOpacity
          style={[styles.sendBtn, (!input.trim() || loading) && styles.sendBtnOff, input.trim() && !loading && SHADOW.crimson]}
          onPress={() => sendMessage(input)}
          disabled={!input.trim() || loading}
          activeOpacity={0.8}
        >
          {loading
            ? <ActivityIndicator size="small" color={COLORS.white} />
            : <Text style={styles.sendIcon}>›</Text>}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: COLORS.ghostWhite },

  header: {
    backgroundColor: COLORS.crimsonDark,
    paddingHorizontal: SPACING.md, paddingTop: SPACING.xl + SPACING.md, paddingBottom: SPACING.md,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    overflow: 'hidden', borderBottomLeftRadius: RADIUS.xl, borderBottomRightRadius: RADIUS.xl,
    marginBottom: SPACING.sm,
  },
  bgCircle: {
    position: 'absolute', top: -40, right: -30, width: 140, height: 140, borderRadius: 70,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  headerLeft:   { flexDirection: 'row', alignItems: 'center', gap: SPACING.sm },
  headerAvatar: {
    width: 40, height: 40, borderRadius: RADIUS.sm,
    backgroundColor: 'rgba(255,255,255,0.20)',
    justifyContent: 'center', alignItems: 'center',
  },
  crossH:       { position: 'absolute', width: 16, height: 4, backgroundColor: COLORS.white, borderRadius: 2 },
  crossV:       { position: 'absolute', width: 4, height: 16, backgroundColor: COLORS.white, borderRadius: 2 },
  headerTitle:  { fontSize: 15, fontWeight: '800', color: COLORS.white },
  onlineRow:    { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 },
  onlineDot:    { width: 6, height: 6, borderRadius: RADIUS.full, backgroundColor: '#69F0AE' },
  onlineText:   { fontSize: 10, color: 'rgba(255,255,255,0.65)', fontWeight: '500' },
  resetBtn: {
    paddingHorizontal: SPACING.sm + 2, paddingVertical: 5,
    borderRadius: RADIUS.sm, borderWidth: 1, borderColor: 'rgba(255,255,255,0.30)',
    backgroundColor: 'rgba(255,255,255,0.10)',
  },
  resetBtnText: { fontSize: 12, color: 'rgba(255,255,255,0.85)', fontWeight: '600' },

  messageList:   { paddingHorizontal: SPACING.md, paddingBottom: SPACING.lg, gap: SPACING.sm },
  bubbleRow:     { flexDirection: 'row', alignItems: 'flex-end', gap: SPACING.sm, marginBottom: SPACING.xs },
  bubbleRowUser: { flexDirection: 'row-reverse' },
  aiAvatar: {
    width: 32, height: 32, borderRadius: RADIUS.xs,
    backgroundColor: COLORS.crimson, justifyContent: 'center', alignItems: 'center', flexShrink: 0,
  },
  bubble:         { maxWidth: '78%', borderRadius: RADIUS.lg, padding: SPACING.sm + 4, gap: 4 },
  bubbleAI:       { backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.mist, borderBottomLeftRadius: 4 },
  bubbleUser:     { backgroundColor: COLORS.crimson, borderBottomRightRadius: 4 },
  bubbleText:     { fontSize: 14, color: COLORS.ink, lineHeight: 21 },
  bubbleTextUser: { color: COLORS.white },
  bubbleTime:     { fontSize: 10, color: COLORS.muted, alignSelf: 'flex-end' },
  bubbleTimeUser: { color: 'rgba(255,255,255,0.60)' },
  loadingBubble:  { flexDirection: 'row', alignItems: 'center', gap: SPACING.sm },
  loadingText:    { fontSize: 13, color: COLORS.muted, fontStyle: 'italic' },

  suggestionsCard: { backgroundColor: COLORS.white, borderRadius: RADIUS.xl, overflow: 'hidden', marginTop: SPACING.sm },
  suggestionsHeader: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm + 2,
    backgroundColor: COLORS.ghostWhite, borderBottomWidth: 1, borderBottomColor: COLORS.mist,
  },
  suggestionsHeaderDot: { width: 8, height: 8, borderRadius: RADIUS.full, backgroundColor: COLORS.crimson },
  suggestionsTitle:     { fontSize: 11, fontWeight: '700', color: COLORS.steel, textTransform: 'uppercase', letterSpacing: 0.8 },
  suggestionItem: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm + 2,
    borderBottomWidth: 1, borderBottomColor: COLORS.mist, gap: SPACING.sm,
  },
  suggestionText:  { flex: 1, fontSize: 13, color: COLORS.slate, fontWeight: '500' },
  suggestionArrow: { fontSize: 20, color: COLORS.crimson, fontWeight: '700' },

  inputBar: {
    flexDirection: 'row', alignItems: 'flex-end',
    backgroundColor: COLORS.white, borderTopWidth: 1, borderTopColor: COLORS.mist,
    paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm, gap: SPACING.sm,
  },
  input: {
    flex: 1, backgroundColor: COLORS.ghostWhite,
    borderWidth: 1.5, borderColor: COLORS.mist, borderRadius: RADIUS.lg,
    paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm + 2,
    fontSize: 14, color: COLORS.ink, maxHeight: 100, fontWeight: '500',
  },
  sendBtn:    { width: 46, height: 46, borderRadius: RADIUS.md, backgroundColor: COLORS.crimson, justifyContent: 'center', alignItems: 'center' },
  sendBtnOff: { backgroundColor: COLORS.mist },
  sendIcon:   { fontSize: 26, color: COLORS.white, fontWeight: '700', lineHeight: 30 },
});
