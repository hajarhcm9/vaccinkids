import React, { useEffect, useState, useContext } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Alert, ActivityIndicator, StatusBar,
} from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import { getAnnonceById, cloturerAnnonce } from '../services/annoncesService';
import { PriorityBadge } from '../components/PriorityBadge';
import { AuthContext } from '../context/AuthContext';
import { Annonce } from '../types';
import { BADGE_COLORS } from '../constants/bloodTypes';
import { COLORS, SPACING, RADIUS, SHADOW } from '../constants/theme';

export const DetailScreen: React.FC = () => {
  const route           = useRoute<any>();
  const navigation      = useNavigation<any>();
  const { userProfile } = useContext(AuthContext);
  const { annonceId }   = route.params as { annonceId: string };

  const [annonce, setAnnonce] = useState<Annonce | null>(null);
  const [loading, setLoading] = useState(true);
  const [closing, setClosing] = useState(false);

  useEffect(() => {
    (async () => {
      const data = await getAnnonceById(annonceId);
      setAnnonce(data);
      setLoading(false);
    })();
  }, [annonceId]);

  const handleCloturer = () => {
    Alert.alert('Clôturer', 'Confirmer la clôture de cette annonce ?', [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Confirmer', style: 'destructive',
        onPress: async () => {
          setClosing(true);
          try {
            await cloturerAnnonce(annonceId);
            Alert.alert('Clôturée', '', [{ text: 'OK', onPress: () => navigation.goBack() }]);
          } catch { Alert.alert('Erreur', 'Impossible de clôturer.'); }
          finally { setClosing(false); }
        },
      },
    ]);
  };

  if (loading) return (
    <View style={styles.center}>
      <ActivityIndicator size="large" color={COLORS.crimson} />
    </View>
  );

  if (!annonce) return (
    <View style={styles.center}>
      <Text style={styles.errorText}>Annonce introuvable.</Text>
    </View>
  );

  const isOwner    = userProfile?.uid === annonce.auteurId;
  const isOffre    = annonce.type === 'offre';
  const accent     = isOffre ? COLORS.success : COLORS.crimson;
  const groups     = isOffre ? annonce.groupePropose : annonce.groupesRecherches?.join(' · ');
  const expDate    = annonce.dateExpiration?.toDate ? annonce.dateExpiration.toDate() : new Date(annonce.dateExpiration);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <StatusBar barStyle="light-content" backgroundColor={accent} />

      {/* Hero banner */}
      <View style={[styles.banner, { backgroundColor: accent }]}>
        <View style={styles.bannerCircle} />
        <Text style={styles.bannerTypeLabel}>
          {isOffre ? 'OFFRE DE DON' : 'BESOIN DE SANG'}
        </Text>
        <Text style={styles.bannerGroup}>{groups}</Text>
        <Text style={styles.bannerAuthor}>{annonce.auteurNom}</Text>
        {annonce.priorityBadge && (
          <View style={{ marginTop: SPACING.sm }}>
            <PriorityBadge badge={annonce.priorityBadge} score={annonce.priorityScore} />
          </View>
        )}
      </View>

      {/* Info card */}
      <View style={styles.infoSection}>
        <View style={[styles.infoCard, SHADOW.card]}>
          {[
            { label: 'Localisation',     value: annonce.localisation },
            { label: 'Date d\'expiration', value: expDate.toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' }) },
            { label: 'Urgence',          value: annonce.urgence === 'urgente' ? 'Urgente' : 'Normale', color: annonce.urgence === 'urgente' ? COLORS.crimson : COLORS.success },
            { label: 'Type',             value: isOffre ? 'Offre de don' : 'Besoin de sang' },
            ...(annonce.priorityRaison ? [{ label: 'Analyse IA', value: annonce.priorityRaison }] : []),
          ].map((row, i, arr) => (
            <View key={i} style={[styles.infoRow, i === arr.length - 1 && { borderBottomWidth: 0 }]}>
              <Text style={styles.infoLabel}>{row.label}</Text>
              <Text style={[styles.infoValue, row.color ? { color: row.color } : {}]} numberOfLines={2}>
                {row.value}
              </Text>
            </View>
          ))}
        </View>
      </View>

      {/* Description */}
      {annonce.description ? (
        <View style={styles.descSection}>
          <Text style={styles.descTitle}>Description</Text>
          <View style={[styles.descCard, SHADOW.soft]}>
            <Text style={styles.descText}>{annonce.description}</Text>
          </View>
        </View>
      ) : null}

      {/* Clôturer */}
      {isOwner && annonce.statut === 'active' && (
        <View style={styles.actionSection}>
          <TouchableOpacity
            style={[styles.clotureBtn, closing && { opacity: 0.6 }, SHADOW.soft]}
            onPress={handleCloturer}
            disabled={closing}
          >
            {closing
              ? <ActivityIndicator color={COLORS.success} />
              : <Text style={styles.clotureBtnText}>MARQUER COMME CLÔTURÉE</Text>}
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.ghostWhite },
  content:   { paddingBottom: SPACING.xxl },
  center:    { flex: 1, justifyContent: 'center', alignItems: 'center' },
  errorText: { fontSize: 15, color: COLORS.muted },

  banner: {
    padding:    SPACING.xl,
    paddingTop: SPACING.xxl,
    overflow:   'hidden',
    borderBottomLeftRadius:  RADIUS.xl,
    borderBottomRightRadius: RADIUS.xl,
    gap:        SPACING.xs,
  },
  bannerCircle: {
    position: 'absolute', top: -50, right: -30,
    width: 160, height: 160, borderRadius: 80,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  bannerTypeLabel: {
    fontSize: 10, fontWeight: '800', color: 'rgba(255,255,255,0.65)',
    letterSpacing: 1.5, textTransform: 'uppercase',
  },
  bannerGroup:  { fontSize: 48, fontWeight: '900', color: COLORS.white, letterSpacing: 0.5 },
  bannerAuthor: { fontSize: 15, color: 'rgba(255,255,255,0.85)', fontWeight: '600' },

  infoSection: { margin: SPACING.md },
  infoCard: {
    backgroundColor: COLORS.white, borderRadius: RADIUS.xl,
    overflow: 'hidden',
  },
  infoRow: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm + 4,
    borderBottomWidth: 1, borderBottomColor: COLORS.mist, gap: SPACING.md,
  },
  infoLabel: { fontSize: 12, color: COLORS.muted, fontWeight: '500', flex: 1 },
  infoValue: { fontSize: 13, fontWeight: '700', color: COLORS.ink, textAlign: 'right', flex: 1.5 },

  descSection:   { marginHorizontal: SPACING.md, gap: SPACING.sm },
  descTitle: {
    fontSize: 11, fontWeight: '700', color: COLORS.steel,
    textTransform: 'uppercase', letterSpacing: 0.8,
  },
  descCard: {
    backgroundColor: COLORS.white, borderRadius: RADIUS.lg,
    padding: SPACING.md,
  },
  descText: { fontSize: 14, color: COLORS.slate, lineHeight: 22 },

  actionSection: { margin: SPACING.md },
  clotureBtn: {
    backgroundColor: COLORS.white, borderRadius: RADIUS.lg,
    paddingVertical: SPACING.md, alignItems: 'center',
    borderWidth: 1.5, borderColor: COLORS.success,
  },
  clotureBtnText: {
    color: COLORS.success, fontSize: 12, fontWeight: '800', letterSpacing: 1.2,
  },
});

