import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, KeyboardAvoidingView, Platform, Alert,
  ActivityIndicator, StatusBar,
} from 'react-native';
import { register, login } from '../services/authService';
import { BLOOD_TYPES }     from '../constants/bloodTypes';
import { BloodType, UserRole } from '../types';
import { COLORS, SPACING, RADIUS, SHADOW } from '../constants/theme';

export const AuthScreen: React.FC = () => {
  const [mode,        setMode]        = useState<'login' | 'register'>('login');
  const [loading,     setLoading]     = useState(false);
  const [email,       setEmail]       = useState('');
  const [password,    setPassword]    = useState('');
  const [nom,         setNom]         = useState('');
  const [idNational,  setIdNational]  = useState('');
  const [role,        setRole]        = useState<UserRole>('donneur');
  const [bloodType,   setBloodType]   = useState<BloodType>('A+');
  const [hopitalNom,  setHopitalNom]  = useState('');
  const [regEmail,    setRegEmail]    = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [confirmPass, setConfirmPass] = useState('');

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Champs requis', 'Veuillez remplir tous les champs.'); return;
    }
    setLoading(true);
    try { await login(email.trim(), password); }
    catch { Alert.alert('Échec', 'Email ou mot de passe incorrect.'); }
    finally { setLoading(false); }
  };

  const handleRegister = async () => {
    if (!nom.trim() || !idNational.trim() || !regEmail.trim() || !regPassword.trim()) {
      Alert.alert('Champs requis', 'Remplissez tous les champs obligatoires.'); return;
    }
    if (regPassword !== confirmPass) {
      Alert.alert('Erreur', 'Les mots de passe ne correspondent pas.'); return;
    }
    if (regPassword.length < 6) {
      Alert.alert('Erreur', 'Mot de passe trop court (min. 6 caractères).'); return;
    }
    if (role === 'hopital' && !hopitalNom.trim()) {
      Alert.alert('Champ requis', "Entrez le nom de l'établissement."); return;
    }
    setLoading(true);
    try {
      await register(
        regEmail.trim(), regPassword, nom.trim(), idNational.trim(), role,
        role === 'donneur' ? bloodType : undefined,
        role === 'hopital' ? hopitalNom.trim() : undefined,
      );
    } catch (e: any) {
      Alert.alert('Échec', e.message || 'Une erreur est survenue.');
    } finally { setLoading(false); }
  };

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <StatusBar barStyle="light-content" backgroundColor={COLORS.crimsonDark} />

      {/* Fond décoratif */}
      <View style={styles.bgTop} />
      <View style={styles.bgCircle1} />
      <View style={styles.bgCircle2} />

      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Hero */}
        <View style={styles.hero}>
          <View style={styles.logoCard}>
            <View style={styles.crossH} />
            <View style={styles.crossV} />
          </View>
          <Text style={styles.appTitle}>BloodConnect</Text>
          <Text style={styles.appSub}>Plateforme nationale de don de sang</Text>
        </View>

        {/* Card principale */}
        <View style={[styles.card, SHADOW.strong]}>

          {/* Onglets */}
          <View style={styles.tabRow}>
            {(['login', 'register'] as const).map(m => (
              <TouchableOpacity
                key={m}
                style={[styles.tab, mode === m && styles.tabActive]}
                onPress={() => setMode(m)}
                activeOpacity={0.7}
              >
                <Text style={[styles.tabText, mode === m && styles.tabTextActive]}>
                  {m === 'login' ? 'Connexion' : 'Inscription'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.form}>
            {mode === 'login' ? (
              <>
                <Field
                  label="Adresse email" value={email} onChangeText={setEmail}
                  keyboardType="email-address" autoCapitalize="none"
                  placeholder="exemple@email.com"
                />
                <Field
                  label="Mot de passe" value={password} onChangeText={setPassword}
                  secureTextEntry placeholder="••••••••"
                />
                <TouchableOpacity
                  style={[styles.btnPrimary, loading && styles.btnDisabled]}
                  onPress={handleLogin}
                  disabled={loading}
                  activeOpacity={0.85}
                >
                  {loading
                    ? <ActivityIndicator color={COLORS.white} />
                    : <Text style={styles.btnPrimaryText}>SE CONNECTER</Text>}
                </TouchableOpacity>
              </>
            ) : (
              <>
                {/* Rôle */}
                <View style={styles.fieldBlock}>
                  <Text style={styles.fieldLabel}>Vous êtes</Text>
                  <View style={styles.roleRow}>
                    {(['donneur', 'hopital'] as UserRole[]).map(r => (
                      <TouchableOpacity
                        key={r}
                        style={[styles.roleChip, role === r && styles.roleChipActive]}
                        onPress={() => setRole(r)}
                        activeOpacity={0.75}
                      >
                        <Text style={[styles.roleChipText, role === r && styles.roleChipTextActive]}>
                          {r === 'donneur' ? 'Donneur' : 'Établissement'}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <Field label="Nom complet" value={nom} onChangeText={setNom} placeholder="Prénom et nom" />
                <Field label="Identifiant national" value={idNational} onChangeText={setIdNational} placeholder="CIN / Passeport" />

                {role === 'hopital' && (
                  <Field
                    label="Nom de l'établissement" value={hopitalNom}
                    onChangeText={setHopitalNom} placeholder="Hôpital / Clinique"
                  />
                )}

                {role === 'donneur' && (
                  <View style={styles.fieldBlock}>
                    <Text style={styles.fieldLabel}>Groupe sanguin</Text>
                    <View style={styles.bloodGrid}>
                      {BLOOD_TYPES.map(bt => (
                        <TouchableOpacity
                          key={bt}
                          style={[styles.bloodChip, bloodType === bt && styles.bloodChipActive]}
                          onPress={() => setBloodType(bt)}
                          activeOpacity={0.75}
                        >
                          <Text style={[styles.bloodChipText, bloodType === bt && styles.bloodChipTextActive]}>
                            {bt}
                          </Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  </View>
                )}

                <Field
                  label="Adresse email" value={regEmail} onChangeText={setRegEmail}
                  keyboardType="email-address" autoCapitalize="none"
                  placeholder="exemple@email.com"
                />
                <Field
                  label="Mot de passe" value={regPassword} onChangeText={setRegPassword}
                  secureTextEntry placeholder="Min. 6 caractères"
                />
                <Field
                  label="Confirmer le mot de passe" value={confirmPass}
                  onChangeText={setConfirmPass} secureTextEntry
                  placeholder="Répétez le mot de passe"
                />

                <TouchableOpacity
                  style={[styles.btnPrimary, loading && styles.btnDisabled]}
                  onPress={handleRegister}
                  disabled={loading}
                  activeOpacity={0.85}
                >
                  {loading
                    ? <ActivityIndicator color={COLORS.white} />
                    : <Text style={styles.btnPrimaryText}>CRÉER MON COMPTE</Text>}
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>

        <Text style={styles.legal}>
          En utilisant BloodConnect, vous contribuez à sauver des vies.
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

// ── Composant champ réutilisable ───────────────────────────────────────────
interface FieldProps {
  label:           string;
  value:           string;
  onChangeText:    (t: string) => void;
  placeholder?:    string;
  secureTextEntry?: boolean;
  keyboardType?:   any;
  autoCapitalize?: any;
}

const Field: React.FC<FieldProps> = ({
  label, value, onChangeText, placeholder,
  secureTextEntry, keyboardType, autoCapitalize,
}) => (
  <View style={styles.fieldBlock}>
    <Text style={styles.fieldLabel}>{label}</Text>
    <TextInput
      style={styles.fieldInput}
      value={value}
      onChangeText={onChangeText}
      placeholder={placeholder}
      placeholderTextColor={COLORS.muted}
      secureTextEntry={secureTextEntry}
      keyboardType={keyboardType || 'default'}
      autoCapitalize={autoCapitalize || 'sentences'}
    />
  </View>
);

// ── Styles ────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  flex:      { flex: 1, backgroundColor: COLORS.ghostWhite },

  bgTop: {
    position:                'absolute',
    top: 0, left: 0, right:  0,
    height:                  280,
    backgroundColor:         COLORS.crimsonDark,
    borderBottomLeftRadius:  RADIUS.xxl + 16,
    borderBottomRightRadius: RADIUS.xxl + 16,
  },
  bgCircle1: {
    position:        'absolute',
    top: -60, right: -60,
    width: 200, height: 200,
    borderRadius:    100,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  bgCircle2: {
    position:        'absolute',
    top: 40, left:   -80,
    width: 240, height: 240,
    borderRadius:    120,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },

  container: { flexGrow: 1, paddingBottom: SPACING.xxl },

  // Hero
  hero: {
    alignItems:    'center',
    paddingTop:    SPACING.xxl + SPACING.lg,
    paddingBottom: SPACING.xl,
  },
  logoCard: {
    width: 64, height: 64,
    borderRadius:    RADIUS.md,
    backgroundColor: 'rgba(255,255,255,0.18)',
    borderWidth:     1,
    borderColor:     'rgba(255,255,255,0.28)',
    justifyContent:  'center',
    alignItems:      'center',
    marginBottom:    SPACING.md,
  },
  crossH:  { position: 'absolute', width: 28, height: 7,  backgroundColor: COLORS.white, borderRadius: 3 },
  crossV:  { position: 'absolute', width: 7,  height: 28, backgroundColor: COLORS.white, borderRadius: 3 },
  appTitle:{ fontSize: 28, fontWeight: '800', color: COLORS.white, letterSpacing: 0.5 },
  appSub:  { fontSize: 12, color: 'rgba(255,255,255,0.60)', marginTop: 4, fontWeight: '500' },

  // Card
  card: {
    marginHorizontal: SPACING.md,
    backgroundColor:  COLORS.white,
    borderRadius:     RADIUS.xl,
    overflow:         'hidden',
  },

  // Tabs
  tabRow: {
    flexDirection:     'row',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.mist,
  },
  tab: {
    flex:              1,
    paddingVertical:   SPACING.md,
    alignItems:        'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabActive:     { borderBottomColor: COLORS.crimson },
  tabText:       { fontSize: 14, fontWeight: '600', color: COLORS.muted },
  tabTextActive: { color: COLORS.ink, fontWeight: '700' },

  form:      { padding: SPACING.lg, gap: SPACING.md },

  // Champs
  fieldBlock: { gap: SPACING.xs },
  fieldLabel: { fontSize: 12, fontWeight: '600', color: COLORS.slate, letterSpacing: 0.3 },
  fieldInput: {
    backgroundColor:   COLORS.ghostWhite,
    borderWidth:       1.5,
    borderColor:       COLORS.mist,
    borderRadius:      RADIUS.md,
    paddingHorizontal: SPACING.md,
    paddingVertical:   SPACING.sm + 4,
    fontSize:          14,
    color:             COLORS.ink,
    fontWeight:        '500',
  },

  // Rôle
  roleRow: { flexDirection: 'row', gap: SPACING.sm },
  roleChip: {
    flex:            1,
    paddingVertical: SPACING.sm + 2,
    borderRadius:    RADIUS.full,
    borderWidth:     1.5,
    borderColor:     COLORS.mist,
    alignItems:      'center',
    backgroundColor: COLORS.ghostWhite,
  },
  roleChipActive:     { borderColor: COLORS.crimson, backgroundColor: COLORS.crimsonFrost ?? 'rgba(139,0,0,0.06)' },
  roleChipText:       { fontSize: 13, fontWeight: '600', color: COLORS.muted },
  roleChipTextActive: { color: COLORS.crimson, fontWeight: '700' },

  // Groupes sanguins
  bloodGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.sm },
  bloodChip: {
    width:           56,
    height:          44,
    justifyContent:  'center',
    alignItems:      'center',
    borderRadius:    RADIUS.full,
    borderWidth:     1.5,
    borderColor:     COLORS.mist,
    backgroundColor: COLORS.ghostWhite,
  },
  bloodChipActive:     { borderColor: COLORS.crimson, backgroundColor: COLORS.crimson },
  bloodChipText:       { fontSize: 14, fontWeight: '800', color: COLORS.steel },
  bloodChipTextActive: { color: COLORS.white },

  // Bouton principal inline — pas de dépendance externe
  btnPrimary: {
    backgroundColor: COLORS.crimson,
    borderRadius:    RADIUS.full,
    paddingVertical: SPACING.md,
    alignItems:      'center',
    marginTop:       SPACING.sm,
    ...SHADOW.crimson,
  },
  btnDisabled:    { opacity: 0.6 },
  btnPrimaryText: { color: COLORS.white, fontSize: 13, fontWeight: '800', letterSpacing: 1.5 },

  legal: {
    textAlign:         'center',
    fontSize:          11,
    color:             COLORS.muted,
    marginTop:         SPACING.lg,
    paddingHorizontal: SPACING.xl,
    lineHeight:        16,
  },
});
