import React, { useState, useContext } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TextInput,
  TouchableOpacity, Alert, ActivityIndicator,
  KeyboardAvoidingView, Platform, Switch, StatusBar,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { createAnnonce } from '../services/annoncesService';
import { AuthContext } from '../context/AuthContext';
import { BLOOD_TYPES } from '../constants/bloodTypes';
import { BloodType, AnnonceType, UrgenceType } from '../types';
import { COLORS, SPACING, RADIUS, SHADOW } from '../constants/theme';

export const PostScreen: React.FC = () => {
  const navigation      = useNavigation<any>();
  const { userProfile } = useContext(AuthContext);

  const [loading,        setLoading]        = useState(false);
  const [type,           setType]           = useState<AnnonceType>('besoin');
  const [urgence,        setUrgence]        = useState<UrgenceType>('normale');
  const [localisation,   setLocalisation]   = useState('');
  const [description,    setDescription]    = useState('');
  const [dateExpiration, setDateExpiration] = useState<Date>(() => {
    const d = new Date(); d.setDate(d.getDate() + 3); return d;
  });
  const [showDate,       setShowDate]       = useState(false);
  const [selectedGroups, setSelectedGroups] = useState<BloodType[]>([]);

  const toggleGroup = (bt: BloodType) =>
    setSelectedGroups(p => p.includes(bt) ? p.filter(g => g !== bt) : [...p, bt]);

  const handleSubmit = async () => {
    if (!localisation.trim()) {
      Alert.alert('Champ requis', 'Veuillez entrer une localisation.'); return;
    }
    if (type === 'besoin' && selectedGroups.length === 0) {
      Alert.alert('Champ requis', 'Sélectionnez au moins un groupe sanguin.'); return;
    }
    setLoading(true);
    try {
      await createAnnonce({
        type,
        auteurId:  userProfile!.uid,
        auteurNom: userProfile!.role === 'hopital'
          ? (userProfile!.hopitalNom ?? userProfile!.nom) : userProfile!.nom,
        role:      userProfile!.role,
        urgence,
        localisation: localisation.trim(),
        description:  description.trim() || undefined,
        dateExpiration,
        ...(type === 'besoin' ? { groupesRecherches: selectedGroups } : {}),
        ...(type === 'offre'  ? { groupePropose: userProfile!.groupeSanguin } : {}),
      });
      Alert.alert('Annonce publiée', 'Votre annonce est maintenant visible.', [
        { text: 'Voir les annonces', onPress: () => navigation.navigate('Home') },
      ]);
    } catch (e: any) {
      Alert.alert('Erreur', e.message || "Impossible de publier l'annonce.");
    } finally { setLoading(false); }
  };

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.crimsonDark} />
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>

        {/* Header */}
        <View style={styles.header}>
          <View style={styles.bgCircle} />
          <Text style={styles.headerTitle}>Nouvelle annonce</Text>
          <Text style={styles.headerSub}>
            {userProfile?.role === 'hopital' ? userProfile?.hopitalNom : userProfile?.nom}
          </Text>
        </View>

        <View style={styles.content}>

          {/* Section : Type */}
          <Section title="Type d'annonce">
            <View style={styles.typeRow}>
              {([
                { val: 'besoin', label: 'Besoin de sang',  color: COLORS.crimson },
                { val: 'offre',  label: 'Offre de don',    color: COLORS.success },
              ] as const).map(({ val, label, color }) => (
                <TouchableOpacity
                  key={val}
                  style={[styles.typeCard, type === val && { borderColor: color, backgroundColor: color + '08' }, SHADOW.soft]}
                  onPress={() => setType(val)}
                >
                  <View style={[styles.typeIndicator, { backgroundColor: type === val ? color : COLORS.fog }]} />
                  <Text style={[styles.typeLabel, type === val && { color }]}>{label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </Section>

          {/* Section : Groupes */}
          <Section title={type === 'besoin' ? 'Groupes sanguins recherchés' : 'Votre groupe sanguin'}>
            {type === 'besoin' ? (
              <View style={styles.bloodGrid}>
                {BLOOD_TYPES.map(bt => (
                  <TouchableOpacity
                    key={bt}
                    style={[
                      styles.bloodChip,
                      selectedGroups.includes(bt) && styles.bloodChipActive,
                      selectedGroups.includes(bt) && SHADOW.crimson,
                    ]}
                    onPress={() => toggleGroup(bt)}
                  >
                    <Text style={[styles.bloodChipText, selectedGroups.includes(bt) && styles.bloodChipTextActive]}>
                      {bt}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            ) : (
              <View style={[styles.singleBlood, SHADOW.soft]}>
                <Text style={styles.singleBloodText}>
                  {userProfile?.groupeSanguin ?? '—'}
                </Text>
                <Text style={styles.singleBloodSub}>Votre groupe sanguin enregistré</Text>
              </View>
            )}
          </Section>

          {/* Section : Urgence */}
          <Section title="Niveau d'urgence">
            <View style={[styles.urgenceCard, SHADOW.soft]}>
              <View style={styles.urgenceLeft}>
                <View style={[styles.urgenceDot, { backgroundColor: urgence === 'urgente' ? COLORS.crimson : COLORS.success }]} />
                <View>
                  <Text style={styles.urgenceTitle}>{urgence === 'urgente' ? 'Urgente' : 'Normale'}</Text>
                  <Text style={styles.urgenceSub}>
                    {urgence === 'urgente' ? 'Notification prioritaire immédiate' : 'Notification standard'}
                  </Text>
                </View>
              </View>
              <Switch
                value={urgence === 'urgente'}
                onValueChange={v => setUrgence(v ? 'urgente' : 'normale')}
                trackColor={{ false: COLORS.mist, true: COLORS.crimson + '50' }}
                thumbColor={urgence === 'urgente' ? COLORS.crimson : COLORS.fog}
              />
            </View>
          </Section>

          {/* Section : Localisation */}
          <Section title="Localisation">
            <TextInput
              style={[styles.input, SHADOW.soft]}
              placeholder="Ex : Hôpital Al Farabi, Oujda"
              placeholderTextColor={COLORS.muted}
              value={localisation}
              onChangeText={setLocalisation}
            />
          </Section>

          {/* Section : Description */}
          <Section title="Description (optionnel)">
            <TextInput
              style={[styles.input, styles.textarea, SHADOW.soft]}
              placeholder="Informations complémentaires..."
              placeholderTextColor={COLORS.muted}
              value={description}
              onChangeText={setDescription}
              multiline
              textAlignVertical="top"
            />
          </Section>

          {/* Section : Date */}
          <Section title="Date limite">
            <TouchableOpacity style={[styles.dateBtn, SHADOW.soft]} onPress={() => setShowDate(true)}>
              <Text style={styles.dateBtnDate}>
                {dateExpiration.toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })}
              </Text>
              <Text style={styles.dateBtnChevron}>›</Text>
            </TouchableOpacity>
            {showDate && (
              <DateTimePicker
                value={dateExpiration} mode="date" minimumDate={new Date()}
                onChange={(_, d) => { setShowDate(false); if (d) setDateExpiration(d); }}
              />
            )}
          </Section>

          {/* Bouton submit */}
          <TouchableOpacity
            style={[styles.submitBtn, loading && styles.submitBtnOff, SHADOW.crimson]}
            onPress={handleSubmit}
            disabled={loading}
          >
            {loading
              ? <ActivityIndicator color={COLORS.white} />
              : <Text style={styles.submitBtnText}>
                  {type === 'besoin' ? 'PUBLIER LE BESOIN' : 'PROPOSER MON DON'}
                </Text>}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <View style={styles.section}>
    <Text style={styles.sectionTitle}>{title}</Text>
    {children}
  </View>
);

const styles = StyleSheet.create({
  flex:      { flex: 1, backgroundColor: COLORS.ghostWhite },
  container: { flexGrow: 1, paddingBottom: SPACING.xxl },

  header: {
    backgroundColor: COLORS.crimsonDark,
    paddingHorizontal: SPACING.md,
    paddingTop:        SPACING.xl + SPACING.md,
    paddingBottom:     SPACING.xl,
    overflow:          'hidden',
    borderBottomLeftRadius:  RADIUS.xl,
    borderBottomRightRadius: RADIUS.xl,
  },
  bgCircle: {
    position: 'absolute', top: -40, right: -40,
    width: 160, height: 160, borderRadius: 80,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  headerTitle: { fontSize: 22, fontWeight: '800', color: COLORS.white, letterSpacing: 0.2 },
  headerSub:   { fontSize: 13, color: 'rgba(255,255,255,0.6)', marginTop: 4 },

  content: { padding: SPACING.md, gap: SPACING.md },

  section:      { gap: SPACING.sm },
  sectionTitle: {
    fontSize: 11, fontWeight: '700', color: COLORS.steel,
    textTransform: 'uppercase', letterSpacing: 0.8,
  },

  typeRow: { flexDirection: 'row', gap: SPACING.sm },
  typeCard: {
    flex: 1, flexDirection: 'row', alignItems: 'center',
    backgroundColor: COLORS.white, borderRadius: RADIUS.md,
    borderWidth: 1.5, borderColor: COLORS.mist,
    paddingVertical: SPACING.md, paddingHorizontal: SPACING.sm, gap: SPACING.sm,
  },
  typeIndicator: { width: 10, height: 10, borderRadius: RADIUS.full },
  typeLabel:     { fontSize: 13, fontWeight: '700', color: COLORS.steel },

  bloodGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.sm },
  bloodChip: {
    width: 58, height: 48, justifyContent: 'center', alignItems: 'center',
    backgroundColor: COLORS.white, borderRadius: RADIUS.md,
    borderWidth: 1.5, borderColor: COLORS.mist,
  },
  bloodChipActive:     { borderColor: COLORS.crimson, backgroundColor: COLORS.crimson },
  bloodChipText:       { fontSize: 14, fontWeight: '800', color: COLORS.steel },
  bloodChipTextActive: { color: COLORS.white },

  singleBlood: {
    backgroundColor: COLORS.white, borderRadius: RADIUS.md,
    padding: SPACING.md, gap: 4,
  },
  singleBloodText: { fontSize: 32, fontWeight: '900', color: COLORS.crimson },
  singleBloodSub:  { fontSize: 12, color: COLORS.muted },

  urgenceCard: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: COLORS.white, borderRadius: RADIUS.md, padding: SPACING.md,
  },
  urgenceLeft:  { flexDirection: 'row', alignItems: 'center', gap: SPACING.sm },
  urgenceDot:   { width: 10, height: 10, borderRadius: RADIUS.full },
  urgenceTitle: { fontSize: 14, fontWeight: '700', color: COLORS.ink },
  urgenceSub:   { fontSize: 11, color: COLORS.muted, marginTop: 2 },

  input: {
    backgroundColor: COLORS.white, borderWidth: 1.5, borderColor: COLORS.mist,
    borderRadius: RADIUS.md, paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm + 4, fontSize: 14, color: COLORS.ink, fontWeight: '500',
  },
  textarea: { height: 100 },

  dateBtn: {
    backgroundColor: COLORS.white, borderRadius: RADIUS.md,
    paddingHorizontal: SPACING.md, paddingVertical: SPACING.md,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
  },
  dateBtnDate:    { fontSize: 14, color: COLORS.ink, fontWeight: '600' },
  dateBtnChevron: { fontSize: 20, color: COLORS.muted },

  submitBtn: {
    backgroundColor: COLORS.crimson, borderRadius: RADIUS.lg,
    paddingVertical: SPACING.md + 2, alignItems: 'center', marginTop: SPACING.sm,
  },
  submitBtnOff:  { opacity: 0.65 },
  submitBtnText: { color: COLORS.white, fontSize: 13, fontWeight: '800', letterSpacing: 1.5 },
});

