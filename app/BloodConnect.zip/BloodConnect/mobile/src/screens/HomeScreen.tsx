import React, { useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  RefreshControl, ActivityIndicator, TextInput, StatusBar,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useAnnonces } from '../hooks/useAnnonces';
import { AnnonceCard } from '../components/AnnonceCard';
import { Annonce } from '../types';
import { COLORS, SPACING, RADIUS, SHADOW } from '../constants/theme';

export const HomeScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const { besoins, offres, loading } = useAnnonces();
  const [activeTab,  setActiveTab]  = useState<'besoins' | 'offres'>('besoins');
  const [search,     setSearch]     = useState('');
  const [refreshing, setRefreshing] = useState(false);

  const data = activeTab === 'besoins' ? besoins : offres;

  const filtered = search.trim()
    ? data.filter(a => {
        const q = search.toLowerCase();
        const g = a.groupesRecherches?.join(' ') ?? a.groupePropose ?? '';
        return (
          a.auteurNom.toLowerCase().includes(q) ||
          a.localisation.toLowerCase().includes(q) ||
          g.toLowerCase().includes(q)
        );
      })
    : data;

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 800);
  };

  return (
    <View style={styles.flex}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.crimsonDark} />

      {/* Header premium */}
      <View style={styles.header}>
        <View style={styles.bgCircle} />
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.greeting}>Bonjour</Text>
            <Text style={styles.headerTitle}>BloodConnect</Text>
          </View>
          <View style={styles.statsRow}>
            <StatChip label="Besoins" value={besoins.length} color={COLORS.crimson} />
            <StatChip label="Offres"  value={offres.length}  color={COLORS.success} />
          </View>
        </View>

        {/* Barre de recherche */}
        <View style={[styles.searchBar, SHADOW.soft]}>
          <View style={styles.searchDot} />
          <TextInput
            style={styles.searchInput}
            placeholder="Groupe, ville, établissement..."
            placeholderTextColor={COLORS.muted}
            value={search}
            onChangeText={setSearch}
          />
          {search.length > 0 && (
            <TouchableOpacity onPress={() => setSearch('')} style={styles.clearBtn}>
              <Text style={styles.clearBtnText}>×</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Sélecteur d'onglet */}
      <View style={styles.tabContainer}>
        <View style={[styles.tabPill, SHADOW.soft]}>
          <TouchableOpacity
            style={[styles.tabOption, activeTab === 'besoins' && styles.tabOptionActive]}
            onPress={() => setActiveTab('besoins')}
          >
            <View style={[styles.tabDot, { backgroundColor: COLORS.crimson }]} />
            <Text style={[styles.tabOptionText, activeTab === 'besoins' && { color: COLORS.crimson }]}>
              Besoins  {besoins.length > 0 && (
                <Text style={styles.tabCount}>{besoins.length}</Text>
              )}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tabOption, activeTab === 'offres' && styles.tabOptionActive]}
            onPress={() => setActiveTab('offres')}
          >
            <View style={[styles.tabDot, { backgroundColor: COLORS.success }]} />
            <Text style={[styles.tabOptionText, activeTab === 'offres' && { color: COLORS.success }]}>
              Offres  {offres.length > 0 && (
                <Text style={styles.tabCount}>{offres.length}</Text>
              )}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Liste */}
      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={COLORS.crimson} />
          <Text style={styles.loadingText}>Chargement...</Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <AnnonceCard
              annonce={item}
              onPress={() => navigation.navigate('Detail', { annonceId: item.id })}
            />
          )}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.crimson} />
          }
          ListEmptyComponent={
            <View style={styles.empty}>
              <View style={[styles.emptyIcon, SHADOW.soft]}>
                <View style={styles.crossH} />
                <View style={styles.crossV} />
              </View>
              <Text style={styles.emptyTitle}>Aucune annonce</Text>
              <Text style={styles.emptyText}>
                {search ? 'Aucun résultat pour cette recherche.'
                  : activeTab === 'besoins'
                  ? 'Aucun besoin de sang enregistré.'
                  : 'Aucune offre de don enregistrée.'}
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
};

const StatChip: React.FC<{ label: string; value: number; color: string }> = ({ label, value, color }) => (
  <View style={[styles.statChip, { borderColor: 'rgba(255,255,255,0.25)' }]}>
    <Text style={[styles.statValue, { color: COLORS.white }]}>{value}</Text>
    <Text style={styles.statLabel}>{label}</Text>
  </View>
);

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: COLORS.ghostWhite },

  header: {
    backgroundColor: COLORS.crimsonDark,
    paddingHorizontal: SPACING.md,
    paddingTop:        SPACING.xl + SPACING.md,
    paddingBottom:     SPACING.lg + 20,
    overflow:          'hidden',
    borderBottomLeftRadius:  RADIUS.xl,
    borderBottomRightRadius: RADIUS.xl,
  },
  bgCircle: {
    position:        'absolute',
    top:             -60, right: -40,
    width:           180, height: 180,
    borderRadius:    90,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  headerContent: {
    flexDirection:  'row',
    justifyContent: 'space-between',
    alignItems:     'flex-start',
    marginBottom:   SPACING.md,
  },
  greeting: {
    fontSize:   12,
    color:      'rgba(255,255,255,0.6)',
    fontWeight: '500',
    letterSpacing: 0.3,
  },
  headerTitle: {
    fontSize:   24,
    fontWeight: '800',
    color:      COLORS.white,
    letterSpacing: 0.2,
    marginTop:  2,
  },
  statsRow: { flexDirection: 'row', gap: SPACING.sm },
  statChip: {
    alignItems:      'center',
    paddingHorizontal: SPACING.sm,
    paddingVertical:   SPACING.xs,
    borderRadius:    RADIUS.sm,
    borderWidth:     1,
    backgroundColor: 'rgba(255,255,255,0.10)',
    minWidth:        52,
  },
  statValue: { fontSize: 18, fontWeight: '800' },
  statLabel: { fontSize: 9, color: 'rgba(255,255,255,0.65)', fontWeight: '600', letterSpacing: 0.3 },

  searchBar: {
    flexDirection:     'row',
    alignItems:        'center',
    backgroundColor:   COLORS.white,
    borderRadius:      RADIUS.md,
    paddingHorizontal: SPACING.md,
    paddingVertical:   SPACING.sm + 2,
    gap:               SPACING.sm,
  },
  searchDot:  { width: 8, height: 8, borderRadius: RADIUS.full, backgroundColor: COLORS.crimson },
  searchInput:{ flex: 1, fontSize: 14, color: COLORS.ink, fontWeight: '500' },
  clearBtn:   { padding: 4 },
  clearBtnText:{ fontSize: 18, color: COLORS.muted, lineHeight: 20 },

  tabContainer: {
    paddingHorizontal: SPACING.md,
    marginTop:         -20,
    marginBottom:      SPACING.sm,
  },
  tabPill: {
    flexDirection:   'row',
    backgroundColor: COLORS.white,
    borderRadius:    RADIUS.lg,
    overflow:        'hidden',
    padding:         4,
    gap:             4,
  },
  tabOption: {
    flex:            1,
    flexDirection:   'row',
    alignItems:      'center',
    justifyContent:  'center',
    paddingVertical: SPACING.sm,
    borderRadius:    RADIUS.md,
    gap:             6,
  },
  tabOptionActive: { backgroundColor: COLORS.ghostWhite },
  tabDot:          { width: 7, height: 7, borderRadius: RADIUS.full },
  tabOptionText:   { fontSize: 13, fontWeight: '700', color: COLORS.muted },
  tabCount:        { fontWeight: '500', fontSize: 12 },

  list:  { paddingTop: SPACING.sm, paddingBottom: SPACING.xxl },
  center:{ flex: 1, justifyContent: 'center', alignItems: 'center', gap: SPACING.sm },
  loadingText: { fontSize: 13, color: COLORS.muted, marginTop: SPACING.sm },

  empty: { alignItems: 'center', paddingTop: SPACING.xxl, paddingHorizontal: SPACING.xl, gap: SPACING.sm },
  emptyIcon: {
    width:           64, height:64,
    borderRadius:    RADIUS.md,
    backgroundColor: COLORS.white,
    justifyContent:  'center', alignItems: 'center',
    marginBottom:    SPACING.sm,
  },
  crossH:    { position: 'absolute', width: 26, height: 7, backgroundColor: COLORS.fog, borderRadius: 3 },
  crossV:    { position: 'absolute', width: 7, height: 26, backgroundColor: COLORS.fog, borderRadius: 3 },
  emptyTitle:{ fontSize: 17, fontWeight: '700', color: COLORS.slate },
  emptyText: { fontSize: 13, color: COLORS.muted, textAlign: 'center', lineHeight: 20 },
});


