import React, { useContext, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Alert, ActivityIndicator, StatusBar,
} from 'react-native';
import { AuthContext } from '../context/AuthContext';
import { logout } from '../services/authService';
import { COLORS, SPACING, RADIUS, SHADOW } from '../constants/theme';

export const ProfileScreen: React.FC = () => {
  const { userProfile } = useContext(AuthContext);
  const [loggingOut, setLoggingOut] = useState(false);

  const handleLogout = () => {
    Alert.alert('Déconnexion', 'Voulez-vous vous déconnecter ?', [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Déconnecter', style: 'destructive',
        onPress: async () => {
          setLoggingOut(true);
          try { await logout(); }
          catch { Alert.alert('Erreur', 'Impossible de se déconnecter.'); }
          finally { setLoggingOut(false); }
        },
      },
    ]);
  };

  if (!userProfile) return (
    <View style={styles.center}>
      <ActivityIndicator size="large" color={COLORS.crimson} />
    </View>
  );

  const isHopital  = userProfile.role === 'hopital';
  const displayName = isHopital ? userProfile.hopitalNom : userProfile.nom;
  const initial    = displayName?.charAt(0).toUpperCase() ?? '?';

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.crimsonDark} />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.bgCircle} />
        <View style={styles.bgCircle2} />

        {/* Avatar */}
        <View style={[styles.avatarRing, SHADOW.strong]}>
          <View style={styles.avatar}>
            <Text style={styles.avatarInitial}>{initial}</Text>
          </View>
        </View>

        <Text style={styles.displayName}>{displayName}</Text>
        <View style={styles.rolePill}>
          <Text style={styles.rolePillText}>
            {isHopital ? 'Établissement hospitalier' : 'Donneur de sang'}
          </Text>
        </View>

        {/* Groupe sanguin en gros */}
        {!isHopital && userProfile.groupeSanguin && (
          <View style={[styles.bloodBig, SHADOW.soft]}>
            <Text style={styles.bloodBigText}>{userProfile.groupeSanguin}</Text>
          </View>
        )}
      </View>

      {/* Infos */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Informations du compte</Text>
        <View style={[styles.card, SHADOW.card]}>
          {[
            { label: 'Nom complet',         value: userProfile.nom },
            { label: 'Identifiant national', value: userProfile.idNational },
            { label: 'Adresse email',        value: userProfile.email },
            ...(isHopital && userProfile.hopitalNom
              ? [{ label: 'Établissement', value: userProfile.hopitalNom }]
              : []),
            ...(!isHopital && userProfile.groupeSanguin
              ? [{ label: 'Groupe sanguin', value: userProfile.groupeSanguin, highlight: true }]
              : []),
            { label: 'Rôle', value: isHopital ? 'Établissement' : 'Donneur' },
          ].map((row: any, i, arr) => (
            <View key={i} style={[styles.row, i === arr.length - 1 && { borderBottomWidth: 0 }]}>
              <Text style={styles.rowLabel}>{row.label}</Text>
              <Text style={[styles.rowValue, row.highlight && styles.rowValueHighlight]}>
                {row.value}
              </Text>
            </View>
          ))}
        </View>
      </View>

      {/* Déconnexion */}
      <View style={styles.section}>
        <TouchableOpacity
          style={[styles.logoutBtn, loggingOut && { opacity: 0.5 }]}
          onPress={handleLogout}
          disabled={loggingOut}
        >
          {loggingOut
            ? <ActivityIndicator color={COLORS.crimson} />
            : <Text style={styles.logoutText}>SE DÉCONNECTER</Text>}
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.ghostWhite },
  content:   { paddingBottom: SPACING.xxl },
  center:    { flex: 1, justifyContent: 'center', alignItems: 'center' },

  header: {
    backgroundColor:   COLORS.crimsonDark,
    alignItems:        'center',
    paddingTop:        SPACING.xxl + SPACING.md,
    paddingBottom:     SPACING.xxl,
    gap:               SPACING.sm,
    overflow:          'hidden',
    borderBottomLeftRadius:  RADIUS.xl,
    borderBottomRightRadius: RADIUS.xl,
  },
  bgCircle: {
    position: 'absolute', top: -50, right: -50,
    width: 200, height: 200, borderRadius: 100,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  bgCircle2: {
    position: 'absolute', bottom: -40, left: -60,
    width: 180, height: 180, borderRadius: 90,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },

  avatarRing: {
    width: 88, height: 88, borderRadius: 44,
    backgroundColor: 'rgba(255,255,255,0.20)',
    justifyContent: 'center', alignItems: 'center',
    marginBottom: SPACING.sm,
  },
  avatar: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: COLORS.white,
    justifyContent: 'center', alignItems: 'center',
  },
  avatarInitial: { fontSize: 30, fontWeight: '900', color: COLORS.crimson },

  displayName: { fontSize: 22, fontWeight: '800', color: COLORS.white, letterSpacing: 0.2 },
  rolePill: {
    backgroundColor:   'rgba(255,255,255,0.15)',
    borderRadius:      RADIUS.full,
    paddingHorizontal: SPACING.md,
    paddingVertical:   4,
    borderWidth:       1,
    borderColor:       'rgba(255,255,255,0.20)',
  },
  rolePillText: { fontSize: 12, color: 'rgba(255,255,255,0.85)', fontWeight: '600' },

  bloodBig: {
    marginTop:         SPACING.sm,
    backgroundColor:   COLORS.white,
    borderRadius:      RADIUS.md,
    paddingHorizontal: SPACING.xl,
    paddingVertical:   SPACING.sm,
  },
  bloodBigText: { fontSize: 28, fontWeight: '900', color: COLORS.crimson, letterSpacing: 1 },

  section:      { margin: SPACING.md, gap: SPACING.sm },
  sectionTitle: {
    fontSize: 11, fontWeight: '700', color: COLORS.steel,
    textTransform: 'uppercase', letterSpacing: 0.8,
  },
  card: {
    backgroundColor: COLORS.white, borderRadius: RADIUS.xl, overflow: 'hidden',
  },
  row: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm + 4,
    borderBottomWidth: 1, borderBottomColor: COLORS.mist, gap: SPACING.md,
  },
  rowLabel:          { fontSize: 12, color: COLORS.muted, fontWeight: '500', flex: 1 },
  rowValue:          { fontSize: 13, fontWeight: '700', color: COLORS.ink, textAlign: 'right', flex: 1.5 },
  rowValueHighlight: { color: COLORS.crimson, fontSize: 18, fontWeight: '900' },

  logoutBtn: {
    borderWidth: 1.5, borderColor: COLORS.crimson,
    borderRadius: RADIUS.lg, paddingVertical: SPACING.md, alignItems: 'center',
  },
  logoutText: { color: COLORS.crimson, fontSize: 12, fontWeight: '800', letterSpacing: 1.2 },
});

