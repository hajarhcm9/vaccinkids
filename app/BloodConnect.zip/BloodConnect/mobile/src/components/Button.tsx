import React from 'react';
import {
  TouchableOpacity, Text, StyleSheet,
  ActivityIndicator, View, ViewStyle, TextStyle,
} from 'react-native';
import { COLORS, RADIUS, SPACING } from '../constants/theme';

export type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'success';
export type ButtonSize    = 'sm' | 'md' | 'lg';

interface ButtonProps {
  label:     string;
  onPress:   () => void;
  variant?:  ButtonVariant;
  size?:     ButtonSize;
  loading?:  boolean;
  disabled?: boolean;
  fullWidth?: boolean;
  style?:    ViewStyle;
  textStyle?: TextStyle;
  icon?:     React.ReactNode;
}

const VARIANT_STYLES: Record<ButtonVariant, {
  bg: string; border: string; text: string; loaderColor: string;
}> = {
  primary:   { bg: COLORS.crimson,     border: COLORS.crimson,     text: '#FFFFFF', loaderColor: '#FFFFFF' },
  secondary: { bg: '#FFFFFF',          border: COLORS.mist,        text: COLORS.ink, loaderColor: COLORS.crimson },
  ghost:     { bg: 'transparent',      border: COLORS.ink,         text: COLORS.ink, loaderColor: COLORS.ink },
  danger:    { bg: 'transparent',      border: COLORS.crimson,     text: COLORS.crimson, loaderColor: COLORS.crimson },
  success:   { bg: COLORS.success,     border: COLORS.success,     text: '#FFFFFF', loaderColor: '#FFFFFF' },
};

const SIZE_STYLES: Record<ButtonSize, {
  paddingV: number; paddingH: number; fontSize: number; radius: number; height: number;
}> = {
  sm: { paddingV: 8,  paddingH: 16, fontSize: 12, radius: RADIUS.full, height: 34 },
  md: { paddingV: 11, paddingH: 20, fontSize: 13, radius: RADIUS.full, height: 42 },
  lg: { paddingV: 14, paddingH: 24, fontSize: 14, radius: RADIUS.full, height: 50 },
};

export const Button: React.FC<ButtonProps> = ({
  label,
  onPress,
  variant   = 'primary',
  size      = 'md',
  loading   = false,
  disabled  = false,
  fullWidth = false,
  style,
  textStyle,
  icon,
}) => {
  const v = VARIANT_STYLES[variant];
  const s = SIZE_STYLES[size];
  const isDisabled = disabled || loading;

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={isDisabled}
      activeOpacity={0.75}
      style={[
        styles.base,
        {
          backgroundColor:  v.bg,
          borderColor:      v.border,
          borderRadius:     s.radius,
          paddingVertical:  s.paddingV,
          paddingHorizontal: s.paddingH,
          height:           s.height,
          width:            fullWidth ? '100%' : undefined,
          alignSelf:        fullWidth ? 'stretch' : 'flex-start',
          opacity:          isDisabled ? 0.5 : 1,
        },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator size="small" color={v.loaderColor} />
      ) : (
        <View style={styles.inner}>
          {icon && <View style={styles.iconWrap}>{icon}</View>}
          <Text
            style={[
              styles.label,
              {
                color:    v.text,
                fontSize: s.fontSize,
              },
              textStyle,
            ]}
          >
            {label}
          </Text>
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  base: {
    borderWidth:     1.5,
    alignItems:      'center',
    justifyContent:  'center',
    flexDirection:   'row',
  },
  inner: {
    flexDirection:  'row',
    alignItems:     'center',
    justifyContent: 'center',
    gap:            SPACING.xs,
  },
  iconWrap: { alignItems: 'center', justifyContent: 'center' },
  label: {
    fontWeight:    '700',
    letterSpacing: 0.2,
    textAlign:     'center',
  },
});
