import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Annonce } from '../types';
import { PriorityBadge } from './PriorityBadge';
import { COLORS, SPACING, RADIUS, SHADOW } from '../constants/theme';

interface Props {
  annonce: Annonce;
  onPress: () => void;
}

export const AnnonceCard: React.FC<Props> = ({ annonce, onPress }) => {
  const isOffre  = annonce.type === 'offre';
  const isUrgent = annonce.urgence === 'urgente';
  const accent   = isOffre ? COLORS.success : COLORS.crimson;

  const groups = isOffre
    ? annonce.groupePropose
    : annonce.groupesRecherches?.join(' · ');

  const expDate = annonce.dateExpiration?.toDate
    ? annonce.dateExpiration.toDate()
    : new Date(annonce.dateExpiration);

  const dateStr = expDate.toLocaleDateString('fr-FR', {
    day: '2-digit', month: 'short', year: 'numeric',
  });

  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.88} style={styles.wrapper}>
      <View style={[styles.card, SHADOW.card]}>

        {/* Bande colorée haut */}
        <View style={[styles.topStripe, { backgroundColor: accent }]}>
          <View style={styles.stripeLeft}>
            <Text style={styles.typeLabel}>
              {isOffre ? 'OFFRE DE DON' : 'BESOIN DE SANG'}
            </Text>
            {isUrgent && (
              <View style={styles.urgentTag}>
                <Text style={styles.urgentText}>URGENT</Text>
              </View>
            )}
          </View>
          {annonce.priorityBadge && (
            <PriorityBadge badge={annonce.priorityBadge} score={annonce.priorityScore} />
          )}
        </View>

        {/* Corps de la carte */}
        <View style={styles.body}>
          {/* Groupe sanguin — élément central */}
          <View style={styles.groupRow}>
            <View style={[styles.groupBadge, { borderColor: accent + '40', backgroundColor: accent + '08' }]}>
              <Text style={[styles.groupText, { color: accent }]}>{groups}</Text>
            </View>
            <View style={styles.metaCol}>
              <Text style={styles.auteurName} numberOfLines={1}>{annonce.auteurNom}</Text>
              <Text style={styles.metaLine} numberOfLines={1}>
                {annonce.localisation}
              </Text>
            </View>
          </View>

          {/* Description */}
          {annonce.description ? (
            <Text style={styles.description} numberOfLines={2}>
              {annonce.description}
            </Text>
          ) : null}

          {/* Footer */}
          <View style={styles.footer}>
            <View style={styles.footerDot} />
            <Text style={styles.footerText}>Expire le {dateStr}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    paddingHorizontal: SPACING.md,
    marginBottom:      SPACING.md,
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius:    RADIUS.xl,
    overflow:        'hidden',
  },

  // ── Bande supérieure colorée ──────────────────────────────────────────────
  topStripe: {
    flexDirection:     'row',
    alignItems:        'center',
    justifyContent:    'space-between',
    paddingHorizontal: SPACING.md,
    paddingVertical:   SPACING.sm + 2,
    gap:               SPACING.sm,
  },
  stripeLeft: {
    flexDirection: 'row',
    alignItems:    'center',
    gap:           SPACING.sm,
  },
  typeLabel: {
    fontSize:      9,
    fontWeight:    '800',
    color:         'rgba(255,255,255,0.9)',
    letterSpacing: 1.2,
  },
  urgentTag: {
    backgroundColor: 'rgba(255,255,255,0.25)',
    borderRadius:    RADIUS.full,
    paddingHorizontal: 7,
    paddingVertical:   2,
  },
  urgentText: {
    fontSize:      8,
    fontWeight:    '800',
    color:         COLORS.white,
    letterSpacing: 0.8,
  },

  // ── Corps ─────────────────────────────────────────────────────────────────
  body: {
    padding: SPACING.md,
    gap:     SPACING.sm,
  },
  groupRow: {
    flexDirection: 'row',
    alignItems:    'center',
    gap:           SPACING.md,
  },
  groupBadge: {
    minWidth:          64,
    height:            64,
    borderRadius:      RADIUS.md,
    borderWidth:       1.5,
    justifyContent:    'center',
    alignItems:        'center',
    paddingHorizontal: SPACING.sm,
  },
  groupText: {
    fontSize:      20,
    fontWeight:    '900',
    letterSpacing: 0.5,
    textAlign:     'center',
  },
  metaCol: { flex: 1, gap: 4 },
  auteurName: {
    fontSize:   15,
    fontWeight: '700',
    color:      COLORS.ink,
    letterSpacing: -0.2,
  },
  metaLine: {
    fontSize:   12,
    color:      COLORS.steel,
    fontWeight: '500',
  },

  description: {
    fontSize:   13,
    color:      COLORS.steel,
    lineHeight: 19,
  },

  footer: {
    flexDirection:  'row',
    alignItems:     'center',
    gap:            6,
    paddingTop:     SPACING.xs,
    borderTopWidth: 1,
    borderTopColor: COLORS.mist,
    marginTop:      SPACING.xs,
  },
  footerDot: {
    width:           5,
    height:          5,
    borderRadius:    RADIUS.full,
    backgroundColor: COLORS.fog,
  },
  footerText: {
    fontSize:   11,
    color:      COLORS.muted,
    fontWeight: '500',
  },
});
