import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { BadgeType } from '../types';
import { BADGE_COLORS, BADGE_BG, BADGE_LABELS } from '../constants/bloodTypes';
import { RADIUS, SPACING } from '../constants/theme';

interface Props {
  badge: BadgeType;
  score?: number;
}

export const PriorityBadge: React.FC<Props> = ({ badge, score }) => {
  const color = BADGE_COLORS[badge];
  const bg    = BADGE_BG[badge];

  return (
    <View style={[styles.container, { backgroundColor: bg, borderColor: color + '30' }]}>
      <View style={[styles.pulse, { backgroundColor: color }]} />
      <Text style={[styles.label, { color }]}>{BADGE_LABELS[badge]}</Text>
      {score !== undefined && (
        <Text style={[styles.score, { color }]}>{score}/10</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection:     'row',
    alignItems:        'center',
    paddingHorizontal: SPACING.sm,
    paddingVertical:   SPACING.xs,
    borderRadius:      RADIUS.full,
    borderWidth:       1,
    alignSelf:         'flex-start',
    gap:               5,
  },
  pulse: {
    width:        6,
    height:       6,
    borderRadius: RADIUS.full,
  },
  label: {
    fontSize:      9,
    fontWeight:    '800',
    letterSpacing: 1,
  },
  score: {
    fontSize:   9,
    fontWeight: '600',
    opacity:    0.8,
  },
});
