import { Router, Response }           from 'express';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';
import { traiterAnnonce }              from '../services/annonceService';
import { db }                          from '../config/firebase';

const router = Router();

// ── POST /api/notifications/test ──────────────────────────────────────────
// Tester une notification sur son propre appareil
router.post(
  '/test',
  authMiddleware,
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const { messaging } = await import('../config/firebase');
      const fcmToken = req.userProfile?.fcmToken;

      if (!fcmToken) {
        res.status(400).json({ success: false, error: 'Aucun token FCM enregistré pour cet utilisateur' });
        return;
      }

      await messaging.send({
        token: fcmToken,
        notification: {
          title: 'BloodConnect — Test',
          body:  'Vos notifications fonctionnent correctement.',
        },
        data: { type: 'test' },
      });

      res.json({ success: true, message: 'Notification de test envoyée' });

    } catch (err) {
      console.error('[POST /notifications/test]', err);
      res.status(500).json({ success: false, error: 'Échec envoi notification de test' });
    }
  }
);

// ── POST /api/notifications/rescore/:annonceId ────────────────────────────
// Re-scorer et re-notifier manuellement
router.post(
  '/rescore/:annonceId',
  authMiddleware,
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const snap = await db.collection('annonces').doc(req.params.annonceId as string).get();
      if (!snap.exists) {
        res.status(404).json({ success: false, error: 'Annonce introuvable' });
        return;
      }

      traiterAnnonce(req.params.annonceId as string).catch(err =>
        console.error(`[Rescore] Erreur :`, err)
      );

      res.json({ success: true, message: 'Re-scoring et re-notification lancés' });

    } catch (err) {
      console.error('[POST /notifications/rescore]', err);
      res.status(500).json({ success: false, error: 'Erreur interne du serveur' });
    }
  }
);

export default router;