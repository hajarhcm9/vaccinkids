router.post('/chat', async (req, res) => {
  const { messages } = req.body;
  try {
    const result = await model.generateContent(messages); // Utilise ton service Gemini déjà créé
    res.json({ text: result.response.text() });
  } catch (error) {
    res.status(500).json({ error: "Erreur IA" });
  }
});