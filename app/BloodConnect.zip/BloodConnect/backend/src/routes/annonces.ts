import { Router, Response } from 'express';
import { db } from '../config/firebase';
import { authMiddleware, AuthRequest } from '../middleware/authMiddleware';
import { validateCreateAnnonce }       from '../middleware/validationMiddleware';
import { traiterAnnonce }              from '../services/annonceService';
import { Annonce, ApiResponse }        from '../config/types';
import admin                           from '../config/firebase';

const router = Router();

// ── POST /api/annonces ─────────────────────────────────────────────────────
// Créer une nouvelle annonce (besoin ou offre) — tout utilisateur connecté
router.post(
  '/',
  authMiddleware,
  validateCreateAnnonce,
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const {
        type, urgence, localisation, description,
        dateExpiration, groupesRecherches, groupePropose,
      } = req.body;

      const user = req.userProfile!;

      const annonceData: Omit<Annonce, 'id'> = {
        type,
        auteurId:  user.uid,
        auteurNom: user.role === 'hopital' ? (user.hopitalNom ?? user.nom) : user.nom,
        role:      user.role,
        urgence,
        localisation: localisation.trim(),
        description:  description?.trim() || undefined,
        dateExpiration: admin.firestore.Timestamp.fromDate(new Date(dateExpiration)),
        statut:       'active',
        createdAt:    admin.firestore.FieldValue.serverTimestamp() as admin.firestore.Timestamp,
        ...(type === 'besoin' ? { groupesRecherches } : {}),
        ...(type === 'offre'  ? { groupePropose: user.groupeSanguin ?? groupePropose } : {}),
      };

      // Enregistrer dans Firestore
      const ref = await db.collection('annonces').add(annonceData);

      // Pipeline IA + notifications (asynchrone — ne bloque pas la réponse)
      traiterAnnonce(ref.id).catch(err =>
        console.error(`[Route] Erreur pipeline annonce ${ref.id}:`, err)
      );

      const response: ApiResponse<{ id: string }> = {
        success: true,
        data:    { id: ref.id },
        message: 'Annonce créée avec succès. Scoring IA et notifications en cours.',
      };
      res.status(201).json(response);

    } catch (err) {
      console.error('[POST /annonces]', err);
      res.status(500).json({ success: false, error: 'Erreur interne du serveur' });
    }
  }
);

// ── GET /api/annonces ──────────────────────────────────────────────────────
// Lister les annonces actives, triées par score IA décroissant
router.get(
  '/',
  authMiddleware,
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const { type, limit = '50' } = req.query;

      let query = db.collection('annonces')
        .where('statut', '==', 'active')
        .orderBy('createdAt', 'desc')
        .limit(parseInt(limit as string, 10));

      if (type === 'besoin' || type === 'offre') {
        query = db.collection('annonces')
          .where('statut', '==', 'active')
          .where('type', '==', type)
          .orderBy('createdAt', 'desc')
          .limit(parseInt(limit as string, 10));
      }

      const snap = await query.get();
      const annonces = snap.docs.map(d => ({ id: d.id, ...d.data() }));

      // Trier par priorityScore côté serveur
      annonces.sort((a: any, b: any) => (b.priorityScore ?? 0) - (a.priorityScore ?? 0));

      res.json({ success: true, data: annonces });

    } catch (err) {
      console.error('[GET /annonces]', err);
      res.status(500).json({ success: false, error: 'Erreur interne du serveur' });
    }
  }
);

// ── GET /api/annonces/:id ──────────────────────────────────────────────────
// Récupérer une annonce par ID
router.get(
  '/:id',
  authMiddleware,
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const snap = await db.collection('annonces').doc(String(req.params.id)).get();
      if (!snap.exists) {
        res.status(404).json({ success: false, error: 'Annonce introuvable' });
        return;
      }
      res.json({ success: true, data: { id: snap.id, ...snap.data() } });

    } catch (err) {
      console.error('[GET /annonces/:id]', err);
      res.status(500).json({ success: false, error: 'Erreur interne du serveur' });
    }
  }
);

// ── PATCH /api/annonces/:id/cloturer ──────────────────────────────────────
// Clôturer une annonce (propriétaire uniquement)
router.patch(
  '/:id/cloturer',
  authMiddleware,
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const ref  = db.collection('annonces').doc(String(req.params.id));
      const snap = await ref.get();

      if (!snap.exists) {
        res.status(404).json({ success: false, error: 'Annonce introuvable' });
        return;
      }

      const annonce = snap.data() as Annonce;
      if (annonce.auteurId !== req.uid) {
        res.status(403).json({ success: false, error: 'Vous n\'êtes pas propriétaire de cette annonce' });
        return;
      }

      await ref.update({
        statut:     'cloturee',
        clotureeAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      res.json({ success: true, message: 'Annonce clôturée avec succès' });

    } catch (err) {
      console.error('[PATCH /annonces/:id/cloturer]', err);
      res.status(500).json({ success: false, error: 'Erreur interne du serveur' });
    }
  }
);

// ── POST /api/annonces/:id/rescore ────────────────────────────────────────
// Re-déclencher manuellement le scoring IA (admin ou propriétaire)
router.post(
  '/:id/rescore',
  authMiddleware,
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const snap = await db.collection('annonces').doc(String(req.params.id)).get();
      if (!snap.exists) {
        res.status(404).json({ success: false, error: 'Annonce introuvable' });
        return;
      }

      // Lancer pipeline en arrière-plan
      traiterAnnonce(String(req.params.id)).catch(err =>
        console.error(`[Route] Erreur rescore ${req.params.id}:`, err)
      );

      res.json({ success: true, message: 'Re-scoring lancé en arrière-plan' });

    } catch (err) {
      console.error('[POST /annonces/:id/rescore]', err);
      res.status(500).json({ success: false, error: 'Erreur interne du serveur' });
    }
  }
);

export default router;