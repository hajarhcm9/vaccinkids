import { Router, Response } from 'express';
import { db }                            from '../config/firebase';
import { authMiddleware, AuthRequest }   from '../middleware/authMiddleware';
import { validateUpdateFcmToken }        from '../middleware/validationMiddleware';
import { User, ApiResponse }             from '../config/types';
import admin                             from '../config/firebase';

const router = Router();

// ── GET /api/users/me ──────────────────────────────────────────────────────
// Récupérer le profil de l'utilisateur connecté
router.get(
  '/me',
  authMiddleware,
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const response: ApiResponse<User> = {
        success: true,
        data:    req.userProfile,
      };
      res.json(response);
    } catch (err) {
      console.error('[GET /users/me]', err);
      res.status(500).json({ success: false, error: 'Erreur interne du serveur' });
    }
  }
);

// ── PATCH /api/users/me/fcm-token ─────────────────────────────────────────
// Mettre à jour le token FCM de l'utilisateur (appelé au démarrage de l'app)
router.patch(
  '/me/fcm-token',
  authMiddleware,
  validateUpdateFcmToken,
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const { fcmToken } = req.body;

      await db.collection('users').doc(req.uid!).update({
        fcmToken,
        fcmTokenUpdatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      res.json({ success: true, message: 'Token FCM mis à jour' });

    } catch (err) {
      console.error('[PATCH /users/me/fcm-token]', err);
      res.status(500).json({ success: false, error: 'Erreur interne du serveur' });
    }
  }
);

// ── GET /api/users/me/annonces ────────────────────────────────────────────
// Lister les annonces de l'utilisateur connecté
router.get(
  '/me/annonces',
  authMiddleware,
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const snap = await db.collection('annonces')
        .where('auteurId', '==', req.uid)
        .orderBy('createdAt', 'desc')
        .limit(30)
        .get();

      const annonces = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      res.json({ success: true, data: annonces });

    } catch (err) {
      console.error('[GET /users/me/annonces]', err);
      res.status(500).json({ success: false, error: 'Erreur interne du serveur' });
    }
  }
);

// ── PATCH /api/users/me ────────────────────────────────────────────────────
// Mettre à jour certains champs du profil
router.patch(
  '/me',
  authMiddleware,
  async (req: AuthRequest, res: Response): Promise<void> => {
    try {
      const allowed  = ['nom', 'localisation', 'description'];
      const updates: Record<string, unknown> = {};

      for (const key of allowed) {
        if (req.body[key] !== undefined) {
          updates[key] = req.body[key];
        }
      }

      if (Object.keys(updates).length === 0) {
        res.status(400).json({ success: false, error: 'Aucun champ valide à mettre à jour' });
        return;
      }

      updates.updatedAt = admin.firestore.FieldValue.serverTimestamp();
      await db.collection('users').doc(req.uid!).update(updates);

      res.json({ success: true, message: 'Profil mis à jour' });

    } catch (err) {
      console.error('[PATCH /users/me]', err);
      res.status(500).json({ success: false, error: 'Erreur interne du serveur' });
    }
  }
);

export default router;