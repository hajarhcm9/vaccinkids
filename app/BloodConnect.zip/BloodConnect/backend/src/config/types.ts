// ─────────────────────────────────────────────────────────────────────────────
// Types partagés — doivent correspondre exactement aux types du frontend mobile
// ─────────────────────────────────────────────────────────────────────────────

export type BloodType   = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
export type UserRole    = 'donneur' | 'hopital';
export type AnnonceType = 'besoin' | 'offre';
export type BadgeType   = 'critique' | 'urgent' | 'normal';
export type UrgenceType = 'normale' | 'urgente';
export type StatutType  = 'active' | 'cloturee';

export interface User {
  uid:           string;
  nom:           string;
  idNational:    string;
  email:         string;
  role:          UserRole;
  groupeSanguin?: BloodType;
  hopitalNom?:   string;
  fcmToken?:     string;
  createdAt?:    FirebaseFirestore.Timestamp;
}

export interface Annonce {
  id?:                string;
  type:               AnnonceType;
  auteurId:           string;
  auteurNom:          string;
  role:               UserRole;
  groupesRecherches?: BloodType[];
  groupePropose?:     BloodType;
  urgence:            UrgenceType;
  localisation:       string;
  description?:       string;
  dateExpiration:     FirebaseFirestore.Timestamp;
  statut:             StatutType;
  priorityScore?:     number;
  priorityBadge?:     BadgeType;
  priorityRaison?:    string;
  notifEnvoyee?:      boolean;
  createdAt?:         FirebaseFirestore.Timestamp;
}

export interface AIScoreResult {
  score:       number;
  badge:       BadgeType;
  raison:      string;
  notif_titre: string;
  notif_corps: string;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?:   T;
  error?:  string;
  message?: string;
}

