import express        from 'express';
import cors           from 'cors';
import helmet         from 'helmet';
import morgan         from 'morgan';
import dotenv         from 'dotenv';

import annoncesRouter      from './routes/annonces';
import usersRouter         from './routes/users';
import notificationsRouter from './routes/notifications';

dotenv.config();

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Sécurité & Middlewares ─────────────────────────────────────────────────
app.use(helmet());
app.use(morgan('dev'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// CORS — autorise le frontend Expo et le navigateur local
const allowedOrigins = (process.env.ALLOWED_ORIGINS ?? '')
  .split(',')
  .map(o => o.trim())
  .filter(Boolean);

app.use(cors({
  origin: (origin, callback) => {
    // Autoriser les requêtes sans origin (app mobile, Postman)
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error(`CORS bloqué pour : ${origin}`));
    }
  },
  methods:     ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
}));

// ── Routes ─────────────────────────────────────────────────────────────────
app.use('/api/annonces',      annoncesRouter);
app.use('/api/users',         usersRouter);
app.use('/api/notifications', notificationsRouter);

// ── Health check ───────────────────────────────────────────────────────────
app.get('/health', (_, res) => {
  res.json({
    status:      'ok',
    service:     'BloodConnect API',
    version:     '1.0.0',
    timestamp:   new Date().toISOString(),
    environment: process.env.NODE_ENV ?? 'development',
  });
});

// ── 404 handler ────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error:   `Route introuvable : ${req.method} ${req.path}`,
  });
});

// ── Global error handler ───────────────────────────────────────────────────
app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('[Server Error]', err.message);
  res.status(500).json({ success: false, error: 'Erreur interne du serveur' });
});

// ── Start ──────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n BloodConnect API démarré`);
  console.log(` Port        : ${PORT}`);
  console.log(` Environment : ${process.env.NODE_ENV ?? 'development'}`);
  console.log(` Firebase    : ${process.env.FIREBASE_PROJECT_ID}`);
  console.log(` Gemini AI   : ${process.env.GEMINI_API_KEY ? 'configuré' : 'NON CONFIGURÉ'}`);
  console.log(` Health      : http://localhost:${PORT}/health\n`);
});

export default app;
;