import { Request, Response, NextFunction } from 'express';
import { auth, db } from '../config/firebase';
import { User } from '../config/types';

// Extend Express Request to include user data
export interface AuthRequest extends Request {
  uid?:         string;
  userProfile?: User;
}

/**
 * Middleware : vérifie le token Firebase ID passé dans Authorization: Bearer <token>
 * et attache le profil utilisateur à la requête
 */
export const authMiddleware = async (
  req:  AuthRequest,
  res:  Response,
  next: NextFunction,
): Promise<void> => {
  const authHeader = req.headers.authorization;

  if (!authHeader?.startsWith('Bearer ')) {
    res.status(401).json({ success: false, error: 'Token manquant ou invalide' });
    return;
  }

  const token = authHeader.split('Bearer ')[1];

  try {
    const decoded = await auth.verifyIdToken(token);
    req.uid = decoded.uid;

    // Charger le profil complet depuis Firestore
    const userSnap = await db.collection('users').doc(decoded.uid).get();
    if (!userSnap.exists) {
      res.status(404).json({ success: false, error: 'Utilisateur introuvable' });
      return;
    }

    req.userProfile = userSnap.data() as User;
    next();

  } catch (err) {
    console.error('[Auth] Token invalide:', err);
    res.status(401).json({ success: false, error: 'Token expiré ou invalide' });
  }
};

/**
 * Middleware : vérifie que l'utilisateur a le rôle 'hopital'
 */
export const hopitalOnly = (
  req:  AuthRequest,
  res:  Response,
  next: NextFunction,
): void => {
  if (req.userProfile?.role !== 'hopital') {
    res.status(403).json({ success: false, error: 'Accès réservé aux établissements hospitaliers' });
    return;
  }
  next();
};

/**
 * Middleware : vérifie que l'utilisateur est le propriétaire de la ressource
 */
export const ownerOnly = (getOwnerId: (req: AuthRequest) => string | undefined) =>
  (req: AuthRequest, res: Response, next: NextFunction): void => {
    const ownerId = getOwnerId(req);
    if (!ownerId || ownerId !== req.uid) {
      res.status(403).json({ success: false, error: 'Accès refusé — vous n\'êtes pas propriétaire' });
      return;
    }
    next();
  };