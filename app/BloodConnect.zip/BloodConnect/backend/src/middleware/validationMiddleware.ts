import { Request, Response, NextFunction } from 'express';

const BLOOD_TYPES  = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const URGENCES     = ['normale', 'urgente'];
const ANNONCE_TYPES = ['besoin', 'offre'];

export const validateCreateAnnonce = (
  req:  Request,
  res:  Response,
  next: NextFunction,
): void => {
  const { type, urgence, localisation, dateExpiration, groupesRecherches, groupePropose } = req.body;

  const errors: string[] = [];

  if (!ANNONCE_TYPES.includes(type)) {
    errors.push('type doit être "besoin" ou "offre"');
  }

  if (!URGENCES.includes(urgence)) {
    errors.push('urgence doit être "normale" ou "urgente"');
  }

  if (!localisation || typeof localisation !== 'string' || localisation.trim().length < 2) {
    errors.push('localisation est requise (min 2 caractères)');
  }

  if (!dateExpiration) {
    errors.push('dateExpiration est requise');
  } else {
    const d = new Date(dateExpiration);
    if (isNaN(d.getTime()) || d <= new Date()) {
      errors.push('dateExpiration doit être une date future valide');
    }
  }

  if (type === 'besoin') {
    if (!Array.isArray(groupesRecherches) || groupesRecherches.length === 0) {
      errors.push('groupesRecherches est requis pour un besoin (tableau non vide)');
    } else {
      const invalides = groupesRecherches.filter((g: string) => !BLOOD_TYPES.includes(g));
      if (invalides.length > 0) {
        errors.push(`Groupes sanguins invalides : ${invalides.join(', ')}`);
      }
    }
  }

  if (type === 'offre') {
    if (!groupePropose || !BLOOD_TYPES.includes(groupePropose)) {
      errors.push('groupePropose est requis pour une offre (groupe sanguin valide)');
    }
  }

  if (errors.length > 0) {
    res.status(400).json({ success: false, error: errors.join(' | ') });
    return;
  }

  next();
};

export const validateUpdateFcmToken = (
  req:  Request,
  res:  Response,
  next: NextFunction,
): void => {
  const { fcmToken } = req.body;
  if (!fcmToken || typeof fcmToken !== 'string' || fcmToken.length < 10) {
    res.status(400).json({ success: false, error: 'fcmToken invalide' });
    return;
  }
  next();
};