import { db } from '../config/firebase';
import { scoreAnnonce }           from './claudeService';
import {
  getTokensDonneurs,
  getTokensHopitauxBesoins,
  envoyerNotifications,
} from './fcmService';
import {
  getDonneursCompatibles,
  getReceveursCompatibles,
} from './compatibiliteService';
import { Annonce, BloodType } from '../config/types';
import admin from '../config/firebase';

/**
 * Pipeline complet :
 * 1. Récupère l'annonce depuis Firestore
 * 2. Score avec Claude IA
 * 3. Met à jour Firestore avec le score
 * 4. Envoie les notifications FCM ciblées
 */
export const traiterAnnonce = async (annonceId: string): Promise<void> => {
  const ref  = db.collection('annonces').doc(annonceId);
  const snap = await ref.get();

  if (!snap.exists) {
    console.error(`[Pipeline] Annonce ${annonceId} introuvable`);
    return;
  }

  const annonce = { id: annonceId, ...snap.data() } as Annonce;

  // ── Étape 1 : Score IA ─────────────────────────────────────────────────
  console.log(`[Pipeline] Scoring IA pour annonce ${annonceId}...`);
  const ai = await scoreAnnonce(annonce);

  // ── Étape 2 : Sauvegarder score dans Firestore ─────────────────────────
  await ref.update({
    priorityScore: ai.score,
    priorityBadge: ai.badge,
    priorityRaison: ai.raison,
    notifEnvoyee:   false,
    scoredAt:       admin.firestore.FieldValue.serverTimestamp(),
  });

  console.log(`[Pipeline] Score IA : ${ai.score}/10 (${ai.badge}) — ${ai.raison}`);

  // ── Étape 3 : Ciblage et envoi notifications ───────────────────────────
  let tokens: string[] = [];

  if (annonce.type === 'besoin') {
    // Hôpital cherche du sang → notifier les donneurs compatibles
    const groupesCompatibles = getDonneursCompatibles(annonce.groupesRecherches ?? []);
    console.log(`[Pipeline] Groupes compatibles : ${groupesCompatibles.join(', ')}`);
    tokens = await getTokensDonneurs(groupesCompatibles as BloodType[]);

  } else if (annonce.type === 'offre' && annonce.groupePropose) {
    // Donneur propose son sang → notifier les hôpitaux ayant des besoins actifs
    console.log(`[Pipeline] Don proposé : ${annonce.groupePropose}`);
    tokens = await getTokensHopitauxBesoins(annonce.groupePropose);
  }

  if (tokens.length === 0) {
    console.log(`[Pipeline] Aucun destinataire trouvé pour ${annonceId}`);
    return;
  }

  console.log(`[Pipeline] Envoi notifications à ${tokens.length} destinataires...`);
  const { succes, echecs } = await envoyerNotifications(tokens, ai, {
    annonceId,
    type: annonce.type,
  });

  // ── Étape 4 : Marquer comme notifié ────────────────────────────────────
  await ref.update({
    notifEnvoyee:  true,
    notifStats: {
      succes,
      echecs,
      total:     tokens.length,
      envoyeAt:  admin.firestore.FieldValue.serverTimestamp(),
    },
  });

  console.log(`[Pipeline] Terminé — ${succes} notifs envoyées, ${echecs} echecs`);
};