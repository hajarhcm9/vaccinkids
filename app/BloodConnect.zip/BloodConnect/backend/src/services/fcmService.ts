import { messaging, db } from '../config/firebase';
import { AIScoreResult, BloodType, UserRole } from '../config/types';

const BADGE_COLORS: Record<string, string> = {
  critique: '#B71C1C',
  urgent:   '#E65100',
  normal:   '#2E7D32',
};

// FCM limite les envois à 500 tokens par requête
const BATCH_SIZE = 500;

/**
 * Récupère les tokens FCM des donneurs dont le groupe sanguin
 * est dans la liste des groupes compatibles
 */
export const getTokensDonneurs = async (groupesCompatibles: BloodType[]): Promise<string[]> => {
  if (groupesCompatibles.length === 0) return [];

  // Firestore limite "in" à 30 valeurs — nos groupes sont max 8
  const snap = await db.collection('users')
    .where('role', '==', 'donneur' as UserRole)
    .where('groupeSanguin', 'in', groupesCompatibles)
    .get();

  return snap.docs
    .map(d => d.data().fcmToken as string | undefined)
    .filter((t): t is string => !!t && t.length > 0);
};

/**
 * Récupère les tokens FCM des hôpitaux ayant des besoins actifs
 * pour un groupe sanguin donné
 */
export const getTokensHopitauxBesoins = async (groupePropose: BloodType): Promise<string[]> => {
  // Hôpitaux avec annonces actives qui cherchent ce groupe
  const snap = await db.collection('annonces')
    .where('statut', '==', 'active')
    .where('type', '==', 'besoin')
    .where('groupesRecherches', 'array-contains', groupePropose)
    .get();

  if (snap.empty) return [];

  // Récupérer les UIDs uniques des hôpitaux
  const hopitalIds = [...new Set(snap.docs.map(d => d.data().auteurId as string))];

  const tokens: string[] = [];
  for (const uid of hopitalIds) {
    const userDoc = await db.collection('users').doc(uid).get();
    const token   = userDoc.data()?.fcmToken as string | undefined;
    if (token) tokens.push(token);
  }
  return tokens;
};

/**
 * Envoie des notifications push par lots de 500
 */
export const envoyerNotifications = async (
  tokens:  string[],
  ai:      AIScoreResult,
  extra:   { annonceId: string; type: string },
): Promise<{ succes: number; echecs: number }> => {
  if (tokens.length === 0) return { succes: 0, echecs: 0 };

  let succes = 0;
  let echecs = 0;

  for (let i = 0; i < tokens.length; i += BATCH_SIZE) {
    const batch = tokens.slice(i, i + BATCH_SIZE);

    try {
      const result = await messaging.sendEachForMulticast({
        tokens: batch,
        notification: {
          title: ai.notif_titre,
          body:  ai.notif_corps,
        },
        data: {
          annonceId: extra.annonceId,
          type:      extra.type,
          badge:     ai.badge,
          score:     String(ai.score),
        },
        android: {
          priority: ai.badge === 'critique' ? 'high' : 'normal',
          notification: {
            color:       BADGE_COLORS[ai.badge],
            channelId:   'blood-alerts',
            priority:    ai.badge === 'critique' ? 'max' : 'default',
            defaultVibrateTimings: true,
          },
        },
        apns: {
          payload: {
            aps: {
              sound:            ai.badge === 'critique' ? 'default' : undefined,
              badge:            1,
              'content-available': 1,
            },
          },
        },
      });

      succes += result.successCount;
      echecs += result.failureCount;

      // Nettoyer les tokens invalides
      result.responses.forEach((resp, idx) => {
        if (!resp.success && resp.error?.code === 'messaging/registration-token-not-registered') {
          console.warn(`[FCM] Token invalide supprimé : ${batch[idx]?.substring(0, 20)}...`);
        }
      });

    } catch (err) {
      console.error(`[FCM] Erreur batch ${i}–${i + BATCH_SIZE}:`, err);
      echecs += batch.length;
    }
  }

  return { succes, echecs };
};