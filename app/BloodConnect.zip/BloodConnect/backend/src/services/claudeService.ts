import { GoogleGenerativeAI } from '@google/generative-ai';
import { Annonce, AIScoreResult } from '../config/types';

// Initialisation de Gemini avec ta clé API du .env
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY ?? '');
// On utilise gemini-1.5-flash pour la rapidité et le coût
const model = genAI.getGenerativeModel({
    model: "gemini-1.5-flash",
    generationConfig: { responseMimeType: "application/json" } // Force le format JSON
});

const buildPrompt = (annonce: Annonce): string => {
  const dateExp = annonce.dateExpiration?.toDate?.()
    ? annonce.dateExpiration.toDate().toLocaleDateString('fr-FR')
    : 'Non définie';

  if (annonce.type === 'besoin') {
    return `Annonce de besoin de sang :
- Groupes sanguins recherchés : ${annonce.groupesRecherches?.join(', ')}
- Niveau d'urgence déclaré    : ${annonce.urgence}
- Établissement               : ${annonce.auteurNom}
- Localisation                : ${annonce.localisation}
- Date d'expiration           : ${dateExp}
- Description                 : ${annonce.description || 'Aucune'}`;
  }

  return `Annonce d'offre de don de sang :
- Groupe sanguin proposé : ${annonce.groupePropose}
- Donneur                : ${annonce.auteurNom}
- Localisation           : ${annonce.localisation}
- Date d'expiration      : ${dateExp}
- Description                 : ${annonce.description || 'Aucune'}`;
};

const buildSystemPrompt = (type: 'besoin' | 'offre'): string => {
  const base = `Tu es un système expert de triage médical pour les dons de sang au Maroc (BloodConnect).
Analyse l'annonce et retourne UNIQUEMENT un objet JSON.

Format de réponse obligatoire :
{
  "score": <nombre entier de 1 à 10>,
  "badge": "critique" | "urgent" | "normal",
  "raison": "explication courte",
  "notif_titre": "titre max 50 chars",
  "notif_corps": "corps max 100 chars"
}

Critères pour un besoin :
- Rare (AB-, O-, B-) → score haut
- Urgence "urgente" → badge urgent/critique
- Score >= 8 → badge "critique"`;

  return type === 'offre'
    ? `${base}\nAnalyse une OFFRE de don pour alerter les hôpitaux.`
    : `${base}\nAnalyse un BESOIN pour alerter les donneurs.`;
};

export const scoreAnnonce = async (annonce: Annonce): Promise<AIScoreResult> => {
  try {
    // Gemini n'utilise pas de "System Prompt" séparé de la même façon que Claude,
    // on combine le rôle et la donnée dans le prompt envoyé.
    const fullPrompt = `${buildSystemPrompt(annonce.type)}\n\nVoici l'annonce à traiter :\n${buildPrompt(annonce)}`;

    const result = await model.generateContent(fullPrompt);
    const response = result.response;
    const text = response.text();

    // Comme on a activé responseMimeType: "application/json", text est déjà un JSON valide
    const parsed: AIScoreResult = JSON.parse(text);

    // Clamp score entre 1 et 10 et validation basique
    return {
      score: Math.min(10, Math.max(1, Math.round(parsed.score || 5))),
      badge: ['critique', 'urgent', 'normal'].includes(parsed.badge) ? parsed.badge : 'normal',
      raison: parsed.raison || 'Annonce analysée',
      notif_titre: parsed.notif_titre || 'BloodConnect',
      notif_corps: parsed.notif_corps || `${annonce.auteurNom} — ${annonce.localisation}`
    };

  } catch (err) {
    console.error('[Gemini] Erreur scoring IA:', err);
    // Fallback identique à ton code original
    return {
      score: annonce.urgence === 'urgente' ? 7 : 4,
      badge: annonce.urgence === 'urgente' ? 'urgent' : 'normal',
      raison: 'Calculé sans IA (mode dégradé)',
      notif_titre: annonce.type === 'besoin' ? 'Besoin de sang' : 'Don disponible',
      notif_corps: `${annonce.auteurNom} — ${annonce.localisation}`,
    };
  }
};