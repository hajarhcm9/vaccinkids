import { BloodType } from '../config/types';

// Table de compatibilité sanguine (donneur → receveur)
// Clé = groupe recherché, Valeur = groupes de donneurs compatibles
export const COMPATIBILITE: Record<BloodType, BloodType[]> = {
  'A+':  ['A+', 'A-', 'O+', 'O-'],
  'A-':  ['A-', 'O-'],
  'B+':  ['B+', 'B-', 'O+', 'O-'],
  'B-':  ['B-', 'O-'],
  'AB+': ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
  'AB-': ['A-', 'B-', 'AB-', 'O-'],
  'O+':  ['O+', 'O-'],
  'O-':  ['O-'],
};

/**
 * Retourne tous les groupes de donneurs compatibles
 * pour une liste de groupes recherchés (sans doublons)
 */
export const getDonneursCompatibles = (groupesRecherches: BloodType[]): BloodType[] => {
  const compatibles = new Set<BloodType>();
  for (const groupe of groupesRecherches) {
    const list = COMPATIBILITE[groupe] ?? [];
    list.forEach(g => compatibles.add(g));
  }
  return Array.from(compatibles);
};

/**
 * Retourne les groupes de receveurs qu'un donneur peut aider
 * (inverse de la table de compatibilité)
 */
export const getReceveursCompatibles = (groupePropose: BloodType): BloodType[] => {
  return (Object.keys(COMPATIBILITE) as BloodType[]).filter(receveur =>
    COMPATIBILITE[receveur].includes(groupePropose)
  );
};